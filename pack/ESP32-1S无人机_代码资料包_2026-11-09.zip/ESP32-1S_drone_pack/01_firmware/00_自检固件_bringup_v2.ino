/*
 * ESP32-1S mini quad bring-up self test  (v2)
 * Board: ESP32-1S-Basic-R4-E07-Layout  (ESP32-S3-WROOM-1 N8R2)
 *
 * SAFETY: every motor PWM pin is forced OUTPUT LOW at the very first line of
 * setup() and is restored to OUTPUT LOW after each probe. Gate pull-downs
 * R11-R14 (100k) keep Q1-Q4 off whenever the pin is high-Z.
 * No motor is driven, no continuous high level is kept on any gate.
 *
 * Pin map from the R4-E07 KiCad netlist (U1 pad -> module pin):
 *   pad4  GPIO4  PWM1 -> R7 330R -> Q1 gate (R11 100k to GND)
 *   pad5  GPIO5  PWM2 -> R8 330R -> Q2 gate (R12 100k to GND)
 *   pad6  GPIO6  PWM3 -> R9 330R -> Q3 gate (R13 100k to GND)
 *   pad7  GPIO7  PWM4 -> R10 330R -> Q4 gate (R14 100k to GND)
 *   pad18 GPIO10 IMU_SDA   (R25 4.7k pull-up)
 *   pad19 GPIO11 IMU_SCL   (R26 4.7k pull-up)
 *   pad20 GPIO12 IMU_INT
 *   pad17 GPIO9  USB_PGOOD_N (R21 10k pull-up, BQ24073 PGOOD# open drain)
 *   pad38 GPIO2  VBAT_ADC   (R3 100k / R4 100k divider) -> ratio 1/2
 *   pad39 GPIO1  NC (ADC1_CH0, used as floating control)
 *   pad12 GPIO8  NC (ADC1_CH7, used as floating control)
 */

#include <WiFi.h>
#include <Wire.h>
#include <esp_mac.h>
#include <esp_system.h>
#include <esp_flash.h>

static const int PIN_PWM[4]      = {4, 5, 6, 7};
static const int PIN_IMU_SDA     = 10;
static const int PIN_IMU_SCL     = 11;
static const int PIN_IMU_INT     = 12;
static const int PIN_PGOOD_N     = 9;
static const int PIN_VBAT_ADC    = 2;
static const int PIN_NC1         = 1;    // pad39, unconnected
static const int PIN_NC2         = 8;    // pad12, unconnected

static const uint8_t QMI_CAND[2] = {0x6A, 0x6B};
static uint8_t g_qmi = 0;
static const float VBAT_DIV_RATIO = 2.0f;

struct Result { const char* id; const char* verdict; char detail[200]; };
static Result g_res[40];
static int g_nres = 0;

struct PinProbe { int pin; uint32_t mvLow, mvFloat, mvPU, mvPD; };

static void addResult(const char* id, const char* verdict, const char* detail) {
  if (g_nres >= 40) return;
  g_res[g_nres].id = id;
  g_res[g_nres].verdict = verdict;
  snprintf(g_res[g_nres].detail, sizeof(g_res[g_nres].detail), "%s", detail);
  g_nres++;
}

static void motorsOff() {
  for (int i = 0; i < 4; i++) {
    digitalWrite(PIN_PWM[i], LOW);
    pinMode(PIN_PWM[i], OUTPUT);
    digitalWrite(PIN_PWM[i], LOW);
  }
}

static uint32_t readMv(int pin, int samples = 24) {
  uint32_t acc = 0;
  for (int i = 0; i < samples; i++) acc += analogReadMilliVolts(pin);
  return acc / samples;
}

// ------------------------------------------------------------------ I2C
static bool i2cWrite(uint8_t addr, uint8_t reg, uint8_t val) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.write(val);
  return Wire.endTransmission() == 0;
}

static bool i2cRead(uint8_t addr, uint8_t reg, uint8_t* buf, uint8_t len) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)addr, (int)len) != len) return false;
  for (uint8_t i = 0; i < len; i++) buf[i] = Wire.read();
  return true;
}

static void scanI2C() {
  char line[256]; line[0] = 0;
  int found = 0;
  for (uint8_t a = 0x08; a < 0x78; a++) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0) {
      char t[24];
      uint8_t r0 = 0xFF, r1 = 0xFF;
      bool ok0 = i2cRead(a, 0x00, &r0, 1);
      bool ok1 = i2cRead(a, 0x01, &r1, 1);
      snprintf(t, sizeof(t), "[0x%02X reg00=%s%02X reg01=%s%02X] ", a,
               ok0 ? "" : "x", r0, ok1 ? "" : "x", r1);
      strncat(line, t, sizeof(line) - strlen(line) - 1);
      found++;
    }
  }
  Serial.printf("[I2C] SDA=GPIO%d SCL=GPIO%d  devices acking: %d  %s\n",
                PIN_IMU_SDA, PIN_IMU_SCL, found, found ? line : "(none)");
  char d[200];
  snprintf(d, sizeof(d), "%d ack: %s", found, found ? line : "none");
  addResult("I2C_BUS", found > 0 ? "PASS" : "FAIL", d);
}

// ------------------------------------------------------------------ tests
static void testIdentity() {
  Serial.println();
  Serial.println("============ 0. CHIP IDENTITY ============");
  uint8_t mac[6]; esp_efuse_mac_get_default(mac);
  uint32_t fsz = 0; esp_flash_get_size(NULL, &fsz);

  Serial.printf("[ID] model      : %s  rev %d  cores %d @ %u MHz\n",
                ESP.getChipModel(), (int)ESP.getChipRevision(),
                (int)ESP.getChipCores(), (unsigned)getCpuFrequencyMhz());
  Serial.printf("[ID] mac        : %02X:%02X:%02X:%02X:%02X:%02X\n",
                mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  Serial.printf("[ID] flash      : %u MB (mode %d, %u MHz)\n",
                (unsigned)(fsz / (1024 * 1024)), (int)ESP.getFlashChipMode(),
                (unsigned)ESP.getFlashChipSpeed() / 1000000u);
  Serial.printf("[ID] psram      : %u bytes total, %u free\n",
                (unsigned)ESP.getPsramSize(), (unsigned)ESP.getFreePsram());
  Serial.printf("[ID] sdk        : %s\n", ESP.getSdkVersion());
  Serial.printf("[ID] sketch md5 : %s\n", ESP.getSketchMD5().c_str());
  Serial.printf("[ID] reset why  : %d\n", (int)esp_reset_reason());
  Serial.printf("[ID] heap       : %u free of %u\n",
                (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getHeapSize());
  Serial.printf("[ID] core temp  : %.1f C (internal, uncalibrated)\n", temperatureRead());

  char d[200];
  snprintf(d, sizeof(d), "%s rev%d, flash %uMB, psram %uKB, sdk %s",
           ESP.getChipModel(), (int)ESP.getChipRevision(),
           (unsigned)(fsz / (1024 * 1024)), (unsigned)(ESP.getPsramSize() / 1024),
           ESP.getSdkVersion());
  addResult("CHIP_ALIVE", "PASS", d);

  snprintf(d, sizeof(d), "total %u KB, free %u KB",
           (unsigned)(ESP.getPsramSize() / 1024), (unsigned)(ESP.getFreePsram() / 1024));
  addResult("PSRAM_2MB", ESP.getPsramSize() >= 1024 * 1024 ? "PASS" : "WARN", d);
}

static void testPowerRails() {
  Serial.println();
  Serial.println("============ 1. POWER / CHARGE PATH ============");

  pinMode(PIN_PGOOD_N, INPUT);
  delay(5);
  uint32_t mvPgood = readMv(PIN_PGOOD_N);
  int lvlPgood = digitalRead(PIN_PGOOD_N);
  Serial.printf("[PWR] USB_PGOOD_N GPIO%d : logic %d, %u mV  (BQ24073 PGOOD#, active low)\n",
                PIN_PGOOD_N, lvlPgood, (unsigned)mvPgood);
  char d[200];
  if (lvlPgood == 0 && mvPgood < 600) {
    snprintf(d, sizeof(d), "asserted low (%umV) -> USB VBUS present, U4 charging path alive", (unsigned)mvPgood);
    addResult("USB_PGOOD", "PASS", d);
  } else {
    snprintf(d, sizeof(d), "logic %d, %umV -> not asserted, check VBUS/U4", lvlPgood, (unsigned)mvPgood);
    addResult("USB_PGOOD", "WARN", d);
  }

  pinMode(PIN_VBAT_ADC, INPUT);
  delay(5);
  uint32_t mvAdc = readMv(PIN_VBAT_ADC, 64);
  float vbat = (mvAdc / 1000.0f) * VBAT_DIV_RATIO;
  Serial.printf("[PWR] VBAT_ADC GPIO%d   : %u mV at pin -> VBAT = %.3f V (divider 100k/100k)\n",
                PIN_VBAT_ADC, (unsigned)mvAdc, vbat);
  Serial.println("[PWR] no cell wired: VBAT_BATT sits at the BQ24073 BAT pin");

  if (mvAdc < 120) {
    snprintf(d, sizeof(d), "VBAT %.2f V (pin %u mV) -> BAT pin near 0", vbat, (unsigned)mvAdc);
    addResult("VBAT_ADC", "WARN", d);
  } else if (vbat > 3.9f && vbat < 4.5f) {
    snprintf(d, sizeof(d), "VBAT %.2f V (pin %u mV) -> BAT pin in charge-regulation band, no cell detected",
             vbat, (unsigned)mvAdc);
    addResult("VBAT_ADC", "PASS", d);
  } else {
    snprintf(d, sizeof(d), "VBAT %.2f V (pin %u mV) -> check divider / BAT pin", vbat, (unsigned)mvAdc);
    addResult("VBAT_ADC", "WARN", d);
  }

  Serial.printf("[PWR] WARNING: VBAT_BATT also feeds JM1..JM4 pad1 (motor + terminal), ~%.1f V live\n", vbat);

  pinMode(PIN_IMU_INT, INPUT_PULLDOWN);
  delay(5);
  Serial.printf("[PWR] IMU_INT GPIO%d     : logic %d with internal pulldown\n",
                PIN_IMU_INT, digitalRead(PIN_IMU_INT));
  pinMode(PIN_IMU_INT, INPUT);
}

static PinProbe probePin(int p) {
  PinProbe r; r.pin = p;
  pinMode(p, OUTPUT); digitalWrite(p, LOW); delay(4); r.mvLow = readMv(p);
  pinMode(p, INPUT);                        delay(6); r.mvFloat = readMv(p);
  pinMode(p, INPUT_PULLUP);                 delay(6); r.mvPU = readMv(p);
  pinMode(p, INPUT_PULLDOWN);               delay(6); r.mvPD = readMv(p);
  pinMode(p, INPUT);
  return r;
}

static void testMotorGateNetwork() {
  Serial.println();
  Serial.println("============ 2. MOTOR GATE NETWORK ============");
  Serial.println("[MOT] every PWM pin held OUTPUT LOW except during the probe window");

  PinProbe pwm[4];
  for (int i = 0; i < 4; i++) pwm[i] = probePin(PIN_PWM[i]);
  PinProbe nc1 = probePin(PIN_NC1);
  PinProbe nc2 = probePin(PIN_NC2);
  motorsOff();

  Serial.printf("[MOT] %-16s %8s %8s %8s %8s\n", "pin", "low", "highZ", "pull-up", "pull-dn");
  for (int i = 0; i < 4; i++) {
    Serial.printf("[MOT] PWM%d GPIO%-2d    %6umV %6umV %6umV %6umV\n", i + 1, pwm[i].pin,
                  (unsigned)pwm[i].mvLow, (unsigned)pwm[i].mvFloat,
                  (unsigned)pwm[i].mvPU, (unsigned)pwm[i].mvPD);
  }
  Serial.printf("[MOT] ref GPIO%-2d (NC) %6umV %6umV %6umV %6umV\n", nc1.pin,
                (unsigned)nc1.mvLow, (unsigned)nc1.mvFloat, (unsigned)nc1.mvPU, (unsigned)nc1.mvPD);
  Serial.printf("[MOT] ref GPIO%-2d (NC) %6umV %6umV %6umV %6umV\n", nc2.pin,
                (unsigned)nc2.mvLow, (unsigned)nc2.mvFloat, (unsigned)nc2.mvPU, (unsigned)nc2.mvPD);
  Serial.println("[MOT] reading order: driven LOW / high-Z / internal pull-up / internal pull-down");
  Serial.println("[MOT] a pin with the 100k gate pulldown resists the weak internal pull-up:");
  Serial.println("[MOT]   hard short to GND -> stays at 0 ; open trace -> rises much higher");

  uint32_t refPU = max(nc1.mvPU, nc2.mvPU);
  char id[20], d[200];
  for (int i = 0; i < 4; i++) {
    snprintf(id, sizeof(id), "PWM%d_GATE", i + 1);
    if (pwm[i].mvLow > 200) {
      snprintf(d, sizeof(d), "driven low reads %umV -> short to 3V3 / leakage", (unsigned)pwm[i].mvLow);
      addResult(id, "FAIL", d);
    } else if (refPU > 800 && pwm[i].mvPU > refPU / 2) {
      snprintf(d, sizeof(d), "pullup %umV vs open-ref %umV -> looks OPEN, check R%d/Q%d",
               (unsigned)pwm[i].mvPU, (unsigned)refPU, 7 + i, i + 1);
      addResult(id, "FAIL", d);
    } else {
      snprintf(d, sizeof(d), "low %umV, highZ %umV, pullup %umV (open-ref %umV) -> 100k pulldown present",
               (unsigned)pwm[i].mvLow, (unsigned)pwm[i].mvFloat,
               (unsigned)pwm[i].mvPU, (unsigned)refPU);
      addResult(id, "PASS", d);
    }
  }
  snprintf(d, sizeof(d), "NC refs pull-up %umV / %umV", (unsigned)nc1.mvPU, (unsigned)nc2.mvPU);
  addResult("GATE_REF", refPU > 800 ? "PASS" : "WARN", d);

  Serial.println("[MOT] cross-channel isolation (one channel HIGH, others INPUT_PULLDOWN)");
  bool isoOK = true;
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4; j++) if (j != i) pinMode(PIN_PWM[j], INPUT_PULLDOWN);
    pinMode(PIN_PWM[i], OUTPUT);
    digitalWrite(PIN_PWM[i], HIGH);
    delay(4);
    char row[128]; row[0] = 0;
    for (int j = 0; j < 4; j++) {
      if (j == i) continue;
      uint32_t mv = readMv(PIN_PWM[j], 12);
      char t[32]; snprintf(t, sizeof(t), "PWM%d=%umV ", j + 1, (unsigned)mv);
      strncat(row, t, sizeof(row) - strlen(row) - 1);
      if (mv > 1200) isoOK = false;
    }
    digitalWrite(PIN_PWM[i], LOW);
    pinMode(PIN_PWM[i], OUTPUT);
    Serial.printf("[MOT]   PWM%d HIGH -> %s\n", i + 1, row);
  }
  motorsOff();
  addResult("MOTOR_ISOLATION", isoOK ? "PASS" : "FAIL",
            isoOK ? "no coupling between PWM1..4 traces" : "cross-channel coupling detected");
  Serial.println("[MOT] all channels restored to OUTPUT LOW");
}

static void testIMU() {
  Serial.println();
  Serial.println("============ 3. IMU  QMI8658A ============");
  Wire.begin(PIN_IMU_SDA, PIN_IMU_SCL, 400000);
  delay(25);
  scanI2C();

  for (int k = 0; k < 2; k++) {
    uint8_t who = 0, rev = 0;
    uint8_t a = QMI_CAND[k];
    bool ok = i2cRead(a, 0x00, &who, 1);
    i2cRead(a, 0x01, &rev, 1);
    Serial.printf("[IMU] addr 0x%02X : WHO_AM_I=0x%02X rev=0x%02X  (%s)\n",
                  a, who, rev, !ok ? "nack" : (who == 0x05 ? "QMI8658A" : "unexpected id"));
    if (ok && who == 0x05) g_qmi = a;
  }

  char d[200];
  if (!g_qmi) {
    snprintf(d, sizeof(d), "no 0x05 identity at 0x6A or 0x6B - check U3 solder / SDO strap");
    addResult("IMU_ID", "FAIL", d);
    addResult("IMU_DATA", "SKIP", "identity not confirmed");
    return;
  }
  snprintf(d, sizeof(d), "QMI8658A answering at 0x%02X (datasheet default with SA0=GND is 0x6A)", g_qmi);
  addResult("IMU_ID", "PASS", d);

  i2cWrite(g_qmi, 0x02, 0x40);   // CTRL1 address auto increment
  i2cWrite(g_qmi, 0x03, 0x24);   // CTRL2 accel +/-8g, ODR idx4
  i2cWrite(g_qmi, 0x04, 0x34);   // CTRL3 gyro +/-128dps, ODR idx4
  i2cWrite(g_qmi, 0x08, 0x03);   // CTRL7 accel+gyro enable
  delay(150);

  uint8_t raw[12] = {0};
  if (!i2cRead(g_qmi, 0x35, raw, 12)) {
    addResult("IMU_DATA", "FAIL", "burst read at 0x35 failed");
    return;
  }
  int16_t ax_ = (int16_t)(raw[1] << 8 | raw[0]);
  int16_t ay_ = (int16_t)(raw[3] << 8 | raw[2]);
  int16_t az_ = (int16_t)(raw[5] << 8 | raw[4]);
  int16_t gx_ = (int16_t)(raw[7] << 8 | raw[6]);
  int16_t gy_ = (int16_t)(raw[9] << 8 | raw[8]);
  int16_t gz_ = (int16_t)(raw[11] << 8 | raw[10]);
  const float aLSB = 4096.0f, gLSB = 256.0f;
  float ax = ax_ / aLSB, ay = ay_ / aLSB, az = az_ / aLSB;
  float gx = gx_ / gLSB, gy = gy_ / gLSB, gz = gz_ / gLSB;
  float amag = sqrtf(ax * ax + ay * ay + az * az);
  float gmag = sqrtf(gx * gx + gy * gy + gz * gz);
  float tilt = atan2f(sqrtf(ax * ax + ay * ay), az) * 57.2958f;

  uint8_t t[2] = {0};
  i2cRead(g_qmi, 0x33, t, 2);
  int16_t traw = (int16_t)(t[1] << 8 | t[0]);

  Serial.printf("[IMU] accel raw  : %6d %6d %6d\n", ax_, ay_, az_);
  Serial.printf("[IMU] accel [g]  : %+7.3f %+7.3f %+7.3f  |a| = %.3f g\n", ax, ay, az, amag);
  Serial.printf("[IMU] gyro  raw  : %6d %6d %6d\n", gx_, gy_, gz_);
  Serial.printf("[IMU] gyro [dps] : %+7.3f %+7.3f %+7.3f  |g| = %.3f dps\n", gx, gy, gz, gmag);
  Serial.printf("[IMU] tilt off vertical : %.1f deg\n", tilt);
  Serial.printf("[IMU] die temp raw %d -> about %.2f C\n", traw, traw / 256.0f + 25.0f);

  if (amag > 0.7f && amag < 1.3f) {
    snprintf(d, sizeof(d), "|a|=%.3fg (tilt %.0fdeg), |g|=%.2fdps at rest", amag, tilt, gmag);
    addResult("IMU_DATA", "PASS", d);
  } else if (amag < 0.05f) {
    snprintf(d, sizeof(d), "accel all zero -> CTRL7/ODR still needs tuning");
    addResult("IMU_DATA", "WARN", d);
  } else {
    snprintf(d, sizeof(d), "|a|=%.3fg -> full-scale assumption wrong", amag);
    addResult("IMU_DATA", "WARN", d);
  }

  Serial.println("[IMU] second sample 400 ms later (board static)");
  delay(400);
  if (i2cRead(g_qmi, 0x35, raw, 12)) {
    ax_ = (int16_t)(raw[1] << 8 | raw[0]); ay_ = (int16_t)(raw[3] << 8 | raw[2]); az_ = (int16_t)(raw[5] << 8 | raw[4]);
    gx_ = (int16_t)(raw[7] << 8 | raw[6]); gy_ = (int16_t)(raw[9] << 8 | raw[8]); gz_ = (int16_t)(raw[11] << 8 | raw[10]);
    Serial.printf("[IMU] accel [g]  : %+7.3f %+7.3f %+7.3f\n",
                  ax_ / aLSB, ay_ / aLSB, az_ / aLSB);
    Serial.printf("[IMU] gyro [dps] : %+7.3f %+7.3f %+7.3f\n",
                  gx_ / gLSB, gy_ / gLSB, gz_ / gLSB);
  }
}

static void testRadio() {
  Serial.println();
  Serial.println("============ 4. 2.4 GHz RADIO ============");
  uint32_t heapBefore = ESP.getFreeHeap();
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(60);
  int n = WiFi.scanNetworks(false, false);
  Serial.printf("[RF] %d networks, heap %u -> %u\n", n,
                (unsigned)heapBefore, (unsigned)ESP.getFreeHeap());
  for (int i = 0; i < n && i < 5; i++) {
    Serial.printf("[RF]   %-24s ch%-3d %4d dBm\n",
                  WiFi.SSID(i).c_str(), WiFi.channel(i), WiFi.RSSI(i));
  }
  char d[200];
  if (n > 0) snprintf(d, sizeof(d), "%d AP seen, strongest %d dBm", n, (int)WiFi.RSSI(0));
  else       snprintf(d, sizeof(d), "0 AP seen - antenna / RF chain to check");
  addResult("WIFI_SCAN", n > 0 ? "PASS" : "WARN", d);
  WiFi.scanDelete();
  WiFi.mode(WIFI_OFF);
}

static void printSummary() {
  Serial.println();
  Serial.println("============ SUMMARY (machine readable) ============");
  for (int i = 0; i < g_nres; i++)
    Serial.printf("RESULT|%-16s|%-4s|%s\n", g_res[i].id, g_res[i].verdict, g_res[i].detail);
  Serial.println("============ END ============");
  Serial.println("[SAFE] motor outputs LOW, radio off, idle");
}

void runAll() {
  g_nres = 0;
  g_qmi = 0;
  motorsOff();
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);

  testIdentity();
  testPowerRails();
  testMotorGateNetwork();
  testIMU();
  testRadio();

  motorsOff();
  printSummary();
}

void setup() {
  motorsOff();

  Serial.begin(115200);
  uint32_t t0 = millis();
  while (!Serial && millis() - t0 < 2000) { delay(10); }
  delay(1200);

  Serial.println();
  Serial.println("####################################################");
  Serial.println("#  ESP32-1S-Basic-R4-E07  BRING-UP SELF TEST v2   #");
  Serial.println("#  motors NOT connected, battery NOT connected     #");
  Serial.println("#  motor PWM forced LOW for the whole run          #");
  Serial.println("####################################################");

  runAll();
}

void loop() {
  static uint32_t last = 0;
  if (Serial.available()) {
    while (Serial.available()) Serial.read();
    Serial.println();
    Serial.println("### RE-RUN REQUESTED BY HOST ###");
    runAll();
  }
  if (millis() - last > 5000) {
    last = millis();
    Serial.printf("[HB] %lus uptime, heap %u, motors OFF\n",
                  (unsigned long)(millis() / 1000), (unsigned)ESP.getFreeHeap());
  }
  delay(100);
}
