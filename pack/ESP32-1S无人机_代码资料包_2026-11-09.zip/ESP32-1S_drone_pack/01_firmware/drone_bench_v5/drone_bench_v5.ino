/*
 * ESP32-1S-Basic-R4-E07  bench telemetry firmware  (v5)
 *
 * v4 -> v5：为"电机振动把 IMU 打花"这件事加的测量与滤波能力
 *   - 主循环不再 20 ms 读一次 IMU，而是 **尽可能快连续采样**（实测 1~2 kHz）
 *   - 每条轴跑一个 2 阶 Butterworth 低通（Q=0.707），陀螺/加速度截止频率可在线改
 *   - 每 200 ms 输出一行 V：原始与滤波后的 RMS（用 Welford 在线方差，数值稳定）
 *   - 输出 dup ‰：相邻两次读到的寄存器块完全相同（说明采样快过 ODR，读到重复值）
 *   - 命令 O,<aODR>,<gODR> 可在不改固件的情况下试不同 ODR 编码
 *
 * v4 的东西全部保留：无锁、四路独立、上限 1000‰、1200 ms 看门狗
 *
 * 上行：
 *   D,<ms>,<vbat_mV>,<pgood>,<ax>,<ay>,<az>,<gx>,<gy>,<gz>,<d1>,<d2>,<d3>,<d4>,<en>,<err>
 *     ax/ay/az 单位 mg（已滤波），gx/gy/gz 单位 0.01 dps（已滤波、已减零偏），d 单位 ‰
 *   V,<ms>,<fs>,<dup‰>,<gRmsXYZ raw>,<gRmsXYZ flt>,<aRmsXYZ raw>,<aRmsXYZ flt>
 *     陀螺 RMS 单位 0.01 dps，加速度 RMS 单位 mg；共 3+3+3+3 = 12 个数
 *   #VER / #FILT / #BOOT / #ACK / #ERR
 *
 * 下行：
 *   P,<ch>,<permille>        单路设定
 *   B,<permille>             四路同设
 *   T,<ch>,<permille>,<ms>   定时点动
 *   X                        全部归零
 *   K                        心跳
 *   F,<fc_gyro>,<fc_acc>     改低通截止频率（Hz），0 表示旁路
 *   O,<aODR>,<gODR>          改 CTRL2/CTRL3 的 ODR 半字节（0..15），立刻重建滤波器
 *   R                        陀螺零偏标定
 *   V                        回 #VER
 *   A                        兼容旧页面，回 #ACK,NO_LOCK
 */

#include <Wire.h>
#include <Arduino.h>
#include <esp_mac.h>

#define FW_VER "v5-vibe"

static const int PIN_PWM[4] = {4, 5, 6, 7};
static const int PIN_SDA = 10, PIN_SCL = 11, PIN_INT = 12;
static const int PIN_VBAT = 2, PIN_PGOOD = 9;

static const uint8_t IMU = 0x6B;
static const float VBAT_DIV = 2.0f;
static const int   DUTY_MAX = 1000;
static const uint32_t WD_MS = 1200;

static const float PI_F = 3.14159265f;

static uint16_t duty[4] = {0, 0, 0, 0};
static uint32_t lastCmdMs = 0;
static uint32_t spinEndMs[4] = {0, 0, 0, 0};
static uint32_t wdTrips = 0;

static float gOff[3] = {0, 0, 0};
static bool  gOffValid = false;

// 滤波器
static float fcG = 60.0f, fcA = 40.0f;   // Hz
static float fsMeas = 1000.0f;

struct LPF { float b0, b1, b2, a1, a2, x1, x2, y1, y2; };
static LPF fA[3], fG[3];

// Welford 统计
struct Stat { float mean; float m2; uint32_t n; };
static Stat stGr[3], stGf[3], stAr[3], stAf[3];   // g raw / g filtered / a raw / a filtered
static Stat stDg[3], stDa[3];                      // 20 ms 窗口，用于 D 帧

static uint32_t dupCnt = 0, totCnt = 0;
static uint32_t i2cFail = 0;
static uint8_t prevBlock[12];

static char rxBuf[64];
static uint8_t rxLen = 0;

// ------------------------------------------------------------------ motor
static void applyDuty() {
  for (int i = 0; i < 4; i++) ledcWrite(PIN_PWM[i], (uint32_t)duty[i] * 1023u / 1000u);
}
static void allOff() {
  for (int i = 0; i < 4; i++) { duty[i] = 0; spinEndMs[i] = 0; }
  applyDuty();
}
static int clampPm(int pm) { return pm < 0 ? 0 : (pm > DUTY_MAX ? DUTY_MAX : pm); }

static void setChannel(int ch, int permille, uint32_t ms) {
  if (ch < 1 || ch > 4) return;
  duty[ch - 1] = (uint16_t)clampPm(permille);
  spinEndMs[ch - 1] = ms ? (millis() + ms) : 0;
  applyDuty();
}

// ------------------------------------------------------------------ filter
static void lpfInit(LPF* f, float fc, float fs) {
  if (fc <= 0.0f) { f->b0 = 1.0f; f->b1 = f->b2 = f->a1 = f->a2 = 0.0f; }
  else {
    if (fc > fs * 0.45f) fc = fs * 0.45f;
    const float w0 = 2.0f * PI_F * fc / fs;
    const float cw = cosf(w0), sw = sinf(w0);
    const float alpha = sw / (2.0f * 0.70710678f);
    const float a0 = 1.0f + alpha;
    f->b0 = (1.0f - cw) * 0.5f / a0;
    f->b1 = (1.0f - cw) / a0;
    f->b2 = f->b0;
    f->a1 = -2.0f * cw / a0;
    f->a2 = (1.0f - alpha) / a0;
  }
  f->x1 = f->x2 = f->y1 = f->y2 = 0.0f;
}

static inline float lpfStep(LPF* f, float x) {
  const float y = f->b0 * x + f->b1 * f->x1 + f->b2 * f->x2 - f->a1 * f->y1 - f->a2 * f->y2;
  f->x2 = f->x1; f->x1 = x;
  f->y2 = f->y1; f->y1 = y;
  return y;
}

static void rebuildFilters() {
  for (int i = 0; i < 3; i++) { lpfInit(&fA[i], fcA, fsMeas); lpfInit(&fG[i], fcG, fsMeas); }
}

static inline void welford(Stat* s, float x) {
  s->n++;
  const float d = x - s->mean;
  s->mean += d / (float)s->n;
  s->m2 += d * (x - s->mean);
}
static inline float stdOf(Stat* s) {
  if (s->n < 2) return 0.0f;
  const float v = s->m2 / (float)(s->n - 1);
  return v > 0.0f ? sqrtf(v) : 0.0f;
}
static inline void welfordReset(Stat* s) { s->mean = 0; s->m2 = 0; s->n = 0; }

// ------------------------------------------------------------------ IMU
static uint8_t ctrl2 = 0x24, ctrl3 = 0x54;   // aODR=2 aFS=4 / gODR=5 gFS=4（实测对应 ±8g / ±512dps）

static bool imuW(uint8_t reg, uint8_t v) {
  Wire.beginTransmission(IMU); Wire.write(reg); Wire.write(v);
  return Wire.endTransmission() == 0;
}
static bool imuR(uint8_t reg, uint8_t* b, uint8_t n) {
  Wire.beginTransmission(IMU); Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)IMU, (int)n) != n) return false;
  for (uint8_t i = 0; i < n; i++) b[i] = Wire.read();
  return true;
}
static bool imuInit() {
  uint8_t who = 0;
  if (!imuR(0x00, &who, 1) || who != 0x05) return false;
  imuW(0x02, 0x40);                    // CTRL1 地址自增
  imuW(0x03, ctrl2);                   // CTRL2 accel
  imuW(0x04, ctrl3);                   // CTRL3 gyro
  imuW(0x08, 0x03);                    // CTRL7 使能
  delay(120);
  return true;
}

// ------------------------------------------------------------------ TX
static void sendVer() {
  uint8_t mac[6];
  esp_efuse_mac_get_default(mac);
  Serial.printf("#VER,%s,%02X:%02X:%02X:%02X:%02X:%02X,imu=0x%02X,div=%d,dutymax=%d,wd=%d\n",
                FW_VER, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5],
                (unsigned)IMU, (int)VBAT_DIV, DUTY_MAX, (int)WD_MS);
  Serial.printf("#FILT,g=%.0f,a=%.0f,fs=%.0f,ctrl2=0x%02X,ctrl3=0x%02X\n",
                fcG, fcA, fsMeas, ctrl2, ctrl3);
}

// ------------------------------------------------------------------ cmd
static void handleLine(char* s) {
  lastCmdMs = millis();
  if (!s[0]) return;
  const char c = s[0];

  if (c == 'K') return;
  if (c == 'X') { allOff(); Serial.println("#ACK,STOP"); return; }
  if (c == 'A') { Serial.println("#ACK,NO_LOCK"); return; }
  if (c == 'V') { sendVer(); return; }

  if (c == 'P') {
    int ch = 0, pm = 0;
    if (sscanf(s, "P,%d,%d", &ch, &pm) == 2 && ch >= 1 && ch <= 4) {
      setChannel(ch, pm, 0);
      Serial.printf("#ACK,P,%d,%d\n", ch, duty[ch - 1]);
    }
    return;
  }
  if (c == 'B') {
    int pm = 0;
    if (sscanf(s, "B,%d", &pm) == 1) {
      pm = clampPm(pm);
      for (int i = 0; i < 4; i++) { duty[i] = (uint16_t)pm; spinEndMs[i] = 0; }
      applyDuty();
      Serial.printf("#ACK,B,%d\n", pm);
    }
    return;
  }
  if (c == 'T') {
    int ch = 0, pm = 0, ms = 0;
    if (sscanf(s, "T,%d,%d,%d", &ch, &pm, &ms) == 3 && ch >= 1 && ch <= 4) {
      if (ms > 5000) ms = 5000;
      if (ms < 20)   ms = 20;
      setChannel(ch, pm, (uint32_t)ms);
      Serial.printf("#ACK,T,%d,%d,%d\n", ch, duty[ch - 1], ms);
    }
    return;
  }
  if (c == 'F') {
    int g = 60, a = 40;
    if (sscanf(s, "F,%d,%d", &g, &a) == 2) {
      fcG = (float)g; fcA = (float)a;
      rebuildFilters();
      Serial.printf("#FILT,g=%.0f,a=%.0f,fs=%.0f,ctrl2=0x%02X,ctrl3=0x%02X\n", fcG, fcA, fsMeas, ctrl2, ctrl3);
    }
    return;
  }
  if (c == 'O') {
    int ao = -1, go = -1;
    if (sscanf(s, "O,%d,%d", &ao, &go) == 2 && ao >= 0 && go >= 0) {
      ctrl2 = (uint8_t)(((ao & 0x0F) << 4) | 0x04);
      ctrl3 = (uint8_t)(((go & 0x0F) << 4) | 0x04);
      // 改 ODR 必须先关再开，否则芯片不生效（实测直接改 dup 完全不变）
      imuW(0x08, 0x00);
      delay(20);
      imuW(0x03, ctrl2);
      imuW(0x04, ctrl3);
      imuW(0x08, 0x03);
      delay(60);
      rebuildFilters();
      Serial.printf("#ACK,O,%d,%d,ctrl2=0x%02X,ctrl3=0x%02X\n", ao, go, ctrl2, ctrl3);
    }
    return;
  }
  if (c == 'R') {
    if (duty[0] || duty[1] || duty[2] || duty[3]) { Serial.println("#ERR,MOTORS_ON"); return; }
    float s3[3] = {0, 0, 0};
    int n = 0;
    uint8_t b[12];
    const uint32_t t0 = millis();
    while (millis() - t0 < 600) {
      if (imuR(0x35, b, 12)) {
        s3[0] += (int16_t)(b[7] << 8 | b[6]);
        s3[1] += (int16_t)(b[9] << 8 | b[8]);
        s3[2] += (int16_t)(b[11] << 8 | b[10]);
        n++;
      }
    }
    if (n > 10) {
      for (int i = 0; i < 3; i++) gOff[i] = s3[i] / (float)n;
      gOffValid = true;
      Serial.printf("#ACK,ZERO,%.1f,%.1f,%.1f\n", gOff[0], gOff[1], gOff[2]);
    } else Serial.println("#ERR,ZERO_FAIL");
    return;
  }
}

// ------------------------------------------------------------------ setup
void setup() {
  for (int i = 0; i < 4; i++) {
    pinMode(PIN_PWM[i], OUTPUT);
    digitalWrite(PIN_PWM[i], LOW);
  }
  delay(2);
  for (int i = 0; i < 4; i++) { ledcAttach(PIN_PWM[i], 20000, 10); ledcWrite(PIN_PWM[i], 0); }
  allOff();

  Serial.begin(115200);
  delay(300);

  Wire.begin(PIN_SDA, PIN_SCL, 400000);
  Wire.setClock(400000);
  const bool imuOK = imuInit();

  pinMode(PIN_PGOOD, INPUT);
  pinMode(PIN_VBAT, INPUT);
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);

  // 实测采样率：连续读 600 次，按微秒计时
  {
    uint8_t b[12];
    const uint32_t t0 = micros();
    int n = 0;
    for (int i = 0; i < 600; i++) if (imuR(0x35, b, 12)) n++;
    const uint32_t dt = micros() - t0;
    if (dt > 0 && n > 10) fsMeas = (float)n * 1000000.0f / (float)dt;
  }
  rebuildFilters();
  memset(prevBlock, 0, sizeof(prevBlock));

  Serial.println();
  Serial.println("#BOOT,ESP32-1S-Basic-R4-E07," FW_VER ",NO_LOCK,4CH,HIRATE");
  Serial.println("#NOTE,no arm needed, 4ch independent, max 1000 permille, watchdog 1200ms");
  sendVer();
  if (!imuOK) Serial.println("#ERR,IMU_INIT");
  lastCmdMs = millis();
}

// ------------------------------------------------------------------ loop
void loop() {
  uint32_t now = millis();

  // ---- 串口 ----
  while (Serial.available()) {
    const char ch = (char)Serial.read();
    if (ch == '\n' || ch == '\r') { rxBuf[rxLen] = 0; if (rxLen) handleLine(rxBuf); rxLen = 0; }
    else if (rxLen < sizeof(rxBuf) - 1) rxBuf[rxLen++] = ch;
  }

  // ---- 连续采样 ----
  uint8_t b[12];
  if (imuR(0x35, b, 12)) {
    if (memcmp(b, prevBlock, 12) == 0) dupCnt++;
    memcpy(prevBlock, b, 12);
    totCnt++;

    const float ax = (int16_t)(b[1] << 8 | b[0]);
    const float ay = (int16_t)(b[3] << 8 | b[2]);
    const float az = (int16_t)(b[5] << 8 | b[4]);
    const float gx = (int16_t)(b[7] << 8 | b[6]);
    const float gy = (int16_t)(b[9] << 8 | b[8]);
    const float gz = (int16_t)(b[11] << 8 | b[10]);

    const float A[3] = {ax, ay, az};
    const float G[3] = {gx, gy, gz};
    float Af[3], Gf[3];
    for (int i = 0; i < 3; i++) {
      Af[i] = lpfStep(&fA[i], A[i]);
      Gf[i] = lpfStep(&fG[i], G[i]);
      welford(&stAr[i], A[i]);
      welford(&stAf[i], Af[i]);
      welford(&stGr[i], G[i]);
      welford(&stGf[i], Gf[i]);
      welford(&stDa[i], Af[i]);
      welford(&stDg[i], Gf[i]);
    }

    // ---- D 帧 50 Hz ----
    static uint32_t lastD = 0;
    if (now - lastD >= 20) {
      lastD = now;
      int errBits = 0;
      if (wdTrips) errBits |= 4;

      static uint32_t vbatAcc = 0; static int vbatN = 0; static uint32_t vbatMv = 0;
      vbatAcc += analogReadMilliVolts(PIN_VBAT); vbatN++;
      if (vbatN >= 5) { vbatMv = vbatAcc / vbatN; vbatAcc = 0; vbatN = 0; }
      if (vbatMv > 4600 || (vbatMv > 0 && vbatMv < 1500)) errBits |= 2;

      float m[3], gg[3];
      for (int i = 0; i < 3; i++) { m[i] = stDa[i].mean; gg[i] = stDg[i].mean; }
      welfordReset(&stDa[0]); welfordReset(&stDa[1]); welfordReset(&stDa[2]);
      welfordReset(&stDg[0]); welfordReset(&stDg[1]); welfordReset(&stDg[2]);

      if (gOffValid) for (int i = 0; i < 3; i++) gg[i] -= gOff[i];

      const int32_t mg_x = (int32_t)(m[0] * 1000.0f / 4096.0f);
      const int32_t mg_y = (int32_t)(m[1] * 1000.0f / 4096.0f);
      const int32_t mg_z = (int32_t)(m[2] * 1000.0f / 4096.0f);
      const int32_t cd_x = (int32_t)(gg[0] * 100.0f / 64.0f);
      const int32_t cd_y = (int32_t)(gg[1] * 100.0f / 64.0f);
      const int32_t cd_z = (int32_t)(gg[2] * 100.0f / 64.0f);

      Serial.printf("D,%lu,%lu,%d,%ld,%ld,%ld,%ld,%ld,%ld,%u,%u,%u,%u,%d,%d\n",
                    (unsigned long)now, (unsigned long)vbatMv, digitalRead(PIN_PGOOD),
                    (long)mg_x, (long)mg_y, (long)mg_z,
                    (long)cd_x, (long)cd_y, (long)cd_z,
                    duty[0], duty[1], duty[2], duty[3], 1, errBits);
    }

    // ---- V 帧 5 Hz：噪声统计 ----
    static uint32_t lastV = 0;
    if (now - lastV >= 200) {
      lastV = now;
      const float dupPm = totCnt ? (1000.0f * (float)dupCnt / (float)totCnt) : 0.0f;
      // 陀螺 RMS -> 0.01 dps；加速度 RMS -> mg
      const float gr0 = stdOf(&stGr[0]), gr1 = stdOf(&stGr[1]), gr2 = stdOf(&stGr[2]);
      const float gf0 = stdOf(&stGf[0]), gf1 = stdOf(&stGf[1]), gf2 = stdOf(&stGf[2]);
      const float ar0 = stdOf(&stAr[0]), ar1 = stdOf(&stAr[1]), ar2 = stdOf(&stAr[2]);
      const float af0 = stdOf(&stAf[0]), af1 = stdOf(&stAf[1]), af2 = stdOf(&stAf[2]);

      Serial.printf("V,%lu,%.0f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.0f,%.0f,%.0f,%.0f,%.0f,%.0f,%u,%u\n",
                    (unsigned long)now, fsMeas, dupPm,
                    gr0, gr1, gr2, gf0, gf1, gf2,
                    ar0 * 1000.0f / 4096.0f, ar1 * 1000.0f / 4096.0f, ar2 * 1000.0f / 4096.0f,
                    af0 * 1000.0f / 4096.0f, af1 * 1000.0f / 4096.0f, af2 * 1000.0f / 4096.0f,
                    (unsigned)(duty[0] + duty[1] + duty[2] + duty[3]),
                    (unsigned)i2cFail);

      for (int i = 0; i < 3; i++) {
        welfordReset(&stGr[i]); welfordReset(&stGf[i]);
        welfordReset(&stAr[i]); welfordReset(&stAf[i]);
      }
      dupCnt = 0; totCnt = 0; i2cFail = 0;
    }
  } else {
    i2cFail++;
  }

  // ---- 定时点动 ----
  bool ended = false;
  for (int i = 0; i < 4; i++) {
    if (spinEndMs[i] && (int32_t)(now - spinEndMs[i]) >= 0) {
      duty[i] = 0; spinEndMs[i] = 0; ended = true;
      Serial.printf("#ACK,T_END,%d\n", i + 1);
    }
  }
  if (ended) applyDuty();

  // ---- 看门狗 ----
  const uint32_t sum = (uint32_t)duty[0] + duty[1] + duty[2] + duty[3];
  if (sum > 0 && (now - lastCmdMs) > WD_MS) {
    allOff(); wdTrips++;
    Serial.println("#ERR,WATCHDOG");
  }
}
