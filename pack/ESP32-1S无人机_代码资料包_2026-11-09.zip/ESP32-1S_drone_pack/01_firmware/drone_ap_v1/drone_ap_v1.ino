/*
 * ESP32-1S-Basic-R4-E07  ·  手机直连测试台  (drone_ap_v1)
 *
 * 和 drone_bench_v5 的区别只有一个：操控通道从"USB 串口 + 网页"换成
 * "自带 WiFi 热点 + 板内 HTTP 服务器"，手机连上热点后浏览器自动弹出控制页。
 *
 *   SSID : DroneBench      （开放网络，无密码）
 *   地址 : http://192.168.4.1/
 *
 * 自动跳转的实现（captive portal）：
 *   1) DNSServer 劫持 53 端口，任何域名都解析到 192.168.4.1
 *   2) HTTP 服务器对未知路径一律回 302 → http://192.168.4.1/
 *   Android 探测 connectivitycheck.gstatic.com/generate_204、iOS 探测
 *   captive.apple.com/hotspot-detect.html，看到 302 就会判定"需要登录"
 *   并自动弹出面板，点开就是控制页。
 *
 * 电机部分完全沿用 v5：无锁、四路独立、上限 1000‰、1200 ms 看门狗。
 * 串口命令行也全部保留，WiFi 出问题时插线一样能控制。
 *
 * 上行（串口仍保留，便于看日志）：
 *   D,<ms>,<vbat_mV>,<pgood>,<ax>,<ay>,<az>,<gx>,<gy>,<gz>,<d1>,<d2>,<d3>,<d4>,<en>,<err>
 *   #VER / #BOOT / #ACK / #ERR / #WIFI
 *
 * 下行（串口）：
 *   P,<ch>,<pm> / B,<pm> / T,<ch>,<pm>,<ms> / X / K / R / V
 *
 * HTTP API：
 *   GET /api/state                     状态 JSON（同时充当心跳）
 *   GET /api/set?ch=1&pm=150           单路设定
 *   GET /api/jog?ch=1&pm=150&ms=1500   定时点动
 *   GET /api/all?pm=200                四路同设
 *   GET /api/stop                      全部归零
 *   GET /api/zero                      陀螺零偏标定
 */

#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Wire.h>
#include <Arduino.h>
#include <esp_mac.h>

#define FW_VER "v6-ap"

static const char* AP_SSID = "DroneBench";     // 开放网络：不传密码
static const uint8_t AP_CH = 6;

static const int PIN_PWM[4] = {4, 5, 6, 7};
static const int PIN_SDA = 10, PIN_SCL = 11;
static const int PIN_VBAT = 2, PIN_PGOOD = 9;

static const uint8_t IMU = 0x6B;
static const float VBAT_DIV = 2.0f;
static const int   DUTY_MAX = 1000;
static const uint32_t WD_MS = 1200;

// 网页通道的硬上限：防止误拖把机身顶飞，也保护 1S 电池
static const int WEB_CH_MAX = 700;    // 单路 70%
static const int WEB_ALL_MAX = 500;   // 四路同开 50%

static const float PI_F = 3.14159265f;

static uint16_t duty[4] = {0, 0, 0, 0};
static uint32_t lastCmdMs = 0;
static uint32_t spinEndMs[4] = {0, 0, 0, 0};
static uint32_t wdTrips = 0;

static float gOff[3] = {0, 0, 0};
static bool  gOffValid = false;

static float fcG = 60.0f, fcA = 40.0f;
static float fsMeas = 1000.0f;

struct LPF { float b0, b1, b2, a1, a2, x1, x2, y1, y2; };
static LPF fA[3], fG[3];

struct Stat { float mean; float m2; uint32_t n; };
static Stat stDa[3], stDg[3];

static int32_t mg[3] = {0, 0, 0};   // 加速度 mg
static int32_t cd[3] = {0, 0, 0};   // 陀螺 0.01 dps
static uint32_t vbatMv = 0;

static uint32_t i2cFail = 0;
static bool imuOK = false;

static char rxBuf[64];
static uint8_t rxLen = 0;

static WebServer server(80);
static DNSServer dns;
static uint32_t lastImuUs = 0;

// ------------------------------------------------------------------ motor
static void applyDuty() {
  for (int i = 0; i < 4; i++) ledcWrite(PIN_PWM[i], (uint32_t)duty[i] * 1023u / 1000u);
}
static void allOff() {
  for (int i = 0; i < 4; i++) { duty[i] = 0; spinEndMs[i] = 0; }
  applyDuty();
}
static int clampPm(int pm) { return pm < 0 ? 0 : (pm > DUTY_MAX ? DUTY_MAX : pm); }

static void setChannel(int ch, int permille, uint32_t ms) {
  if (ch < 1 || ch > 4) return;
  duty[ch - 1] = (uint16_t)clampPm(permille);
  spinEndMs[ch - 1] = ms ? (millis() + ms) : 0;
  applyDuty();
}

// ------------------------------------------------------------------ filter
static void lpfInit(LPF* f, float fc, float fs) {
  if (fc <= 0.0f) { f->b0 = 1.0f; f->b1 = f->b2 = f->a1 = f->a2 = 0.0f; }
  else {
    if (fc > fs * 0.45f) fc = fs * 0.45f;
    const float w0 = 2.0f * PI_F * fc / fs;
    const float cw = cosf(w0), sw = sinf(w0);
    const float alpha = sw / (2.0f * 0.70710678f);
    const float a0 = 1.0f + alpha;
    f->b0 = (1.0f - cw) * 0.5f / a0;
    f->b1 = (1.0f - cw) / a0;
    f->b2 = f->b0;
    f->a1 = -2.0f * cw / a0;
    f->a2 = (1.0f - alpha) / a0;
  }
  f->x1 = f->x2 = f->y1 = f->y2 = 0.0f;
}
static inline float lpfStep(LPF* f, float x) {
  const float y = f->b0 * x + f->b1 * f->x1 + f->b2 * f->x2 - f->a1 * f->y1 - f->a2 * f->y2;
  f->x2 = f->x1; f->x1 = x;
  f->y2 = f->y1; f->y1 = y;
  return y;
}
static void rebuildFilters() {
  for (int i = 0; i < 3; i++) { lpfInit(&fA[i], fcA, fsMeas); lpfInit(&fG[i], fcG, fsMeas); }
}

static inline void welford(Stat* s, float x) {
  s->n++;
  const float d = x - s->mean;
  s->mean += d / (float)s->n;
  s->m2 += d * (x - s->mean);
}
static inline void welfordReset(Stat* s) { s->mean = 0; s->m2 = 0; s->n = 0; }

// ------------------------------------------------------------------ IMU
static uint8_t ctrl2 = 0x24, ctrl3 = 0x54;   // ±8g / ±512dps

static bool imuW(uint8_t reg, uint8_t v) {
  Wire.beginTransmission(IMU); Wire.write(reg); Wire.write(v);
  return Wire.endTransmission() == 0;
}
static bool imuR(uint8_t reg, uint8_t* b, uint8_t n) {
  Wire.beginTransmission(IMU); Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)IMU, (int)n) != n) return false;
  for (uint8_t i = 0; i < n; i++) b[i] = Wire.read();
  return true;
}
static bool imuInit() {
  uint8_t who = 0;
  if (!imuR(0x00, &who, 1) || who != 0x05) return false;
  imuW(0x02, 0x40);                    // CTRL1 地址自增
  imuW(0x03, ctrl2);
  imuW(0x04, ctrl3);
  imuW(0x08, 0x03);                    // CTRL7 使能
  delay(120);
  return true;
}

// ------------------------------------------------------------------ 页面
static const char PAGE_HTML[] PROGMEM = R"HTML(<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0b1220">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<title>无人机测试台</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0}
body{background:#0b1220;color:#e2ebf8;
 font:15px/1.45 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",system-ui,sans-serif;
 padding:calc(env(safe-area-inset-top) + 10px) 12px calc(env(safe-area-inset-bottom) + 22px);
 max-width:520px;margin:0 auto}
.bar{display:flex;align-items:center;gap:7px;font-size:12px;color:#8fa3bd;
 background:#111c2c;border:1px solid #1e2c40;border-radius:11px;padding:9px 12px}
.bar b{color:#e2ebf8;font-weight:600}
.dot{width:7px;height:7px;border-radius:50%;background:#3ddc84;box-shadow:0 0 7px #3ddc84;flex:none}
.dot.off{background:#f2545b;box-shadow:0 0 7px #f2545b}
h1{font-size:12.5px;font-weight:600;color:#7d90a9;margin:17px 0 8px;letter-spacing:.05em}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
.m{background:#111c2c;border:1px solid #1e2c40;border-radius:14px;padding:11px 11px 12px}
.m .hd{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:7px}
.m .hd b{font-size:15px}
.m .hd span{font-size:11px;color:#7d90a9}
.m .pv{font:600 21px ui-monospace,Menlo,monospace;color:#42556d;margin-bottom:9px}
.m .pv.on{color:#2fd3c0}
button{font:inherit;font-size:15px;font-weight:600;border-radius:11px;border:1px solid #2a3b52;
 background:#1a2739;color:#d5e2f2;padding:12px 10px;width:100%;cursor:pointer;
 transition:transform .06s,background .15s,border-color .15s,color .15s}
button:active{transform:scale(.97)}
button.spin{background:linear-gradient(180deg,#f2b544,#d99521);border-color:#f7c76a;color:#20160a}
button.run{background:linear-gradient(180deg,#f2b544,#d99521);border-color:#f7c76a;color:#20160a}
button.danger{background:#3a1a20;border-color:#6b2b34;color:#ff9aa0}
button.ghost{background:#141f2e;color:#9fb2c9}
button:disabled{opacity:.45}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:9px}
.sl{background:#111c2c;border:1px solid #1e2c40;border-radius:14px;padding:12px 14px 8px;margin-top:9px}
.sl .t{display:flex;justify-content:space-between;align-items:baseline;font-size:13px;color:#9fb2c9}
.sl .t b{font:600 18px ui-monospace,Menlo,monospace;color:#2fd3c0}
input[type=range]{-webkit-appearance:none;appearance:none;width:100%;height:34px;background:transparent;margin:0}
input[type=range]::-webkit-slider-runnable-track{height:8px;border-radius:5px;background:#1d2b3e}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:30px;height:30px;margin-top:-11px;
 border-radius:50%;background:#2fd3c0;border:3px solid #0b1220;box-shadow:0 0 0 1px #2fd3c0}
input[type=range]::-moz-range-track{height:8px;border-radius:5px;background:#1d2b3e}
input[type=range]::-moz-range-thumb{width:26px;height:26px;border:3px solid #0b1220;border-radius:50%;background:#2fd3c0}
.log{background:#0d1622;border:1px solid #1a2634;border-radius:11px;padding:9px 11px;
 font:11.5px/1.65 ui-monospace,Menlo,monospace;color:#7f93ab;max-height:140px;overflow-y:auto;margin-top:9px}
.log b{color:#2fd3c0;font-weight:600}
.log i{color:#f2b544;font-style:normal}
.hl{background:#111c2c;border:1px solid #1e2c40;border-radius:11px;padding:10px 12px;
 font-size:12px;color:#8ea2ba;line-height:1.8;margin-top:9px}
.hl b{color:#dbe6f4}
.hl i{color:#f2b544;font-style:normal}
.att{display:flex;gap:16px;align-items:center;padding:2px 2px 6px}
.bub{position:relative;width:82px;height:82px;border-radius:50%;border:1px solid #26364c;
 background:radial-gradient(circle,#16233a 0%,#0f1a28 100%);flex:none;overflow:hidden}
.bub::before,.bub::after{content:"";position:absolute;background:#223146}
.bub::before{left:50%;top:8px;bottom:8px;width:1px}
.bub::after{top:50%;left:8px;right:8px;height:1px}
.bub span{position:absolute;width:15px;height:15px;border-radius:50%;background:#2fd3c0;
 left:50%;top:50%;margin:-7.5px 0 0 -7.5px;box-shadow:0 0 12px rgba(47,211,192,.65)}
.att .n{flex:1;font:12.5px/2 ui-monospace,Menlo,monospace;color:#8fa3bd}
.att .n b{color:#e2ebf8;font-weight:600}
</style></head><body>

<div class="bar"><span class="dot" id="dot"></span><b id="sBatt">--</b>
<span>·</span><span id="sSta">0</span><span>台连接</span>
<span style="flex:1"></span><span id="sUp">--</span></div>

<h1>点一下 · 转 1.5 秒自己停</h1>
<div class="grid" id="grid"></div>

<h1>四路同开</h1>
<div class="sl">
  <div class="t"><span>油门</span><b id="mv">0%</b></div>
  <input type="range" id="ms" min="0" max="45" value="0" step="1">
</div>
<div class="row2">
  <button class="danger" id="stop">全部停止</button>
  <button class="ghost" id="zero">陀螺零偏</button>
</div>

<h1>推力阶梯测试</h1>
<button class="ghost" id="ramp">6 → 24% · 每档 4 秒</button>
<div class="log" id="log">就绪</div>

<h1>姿态</h1>
<div class="sl"><div class="att">
  <div class="bub"><span id="bubDot"></span></div>
  <div class="n">roll <b id="nRoll">0.0°</b><br>pitch <b id="nPitch">0.0°</b><br>a <b id="nAcc">0.00g</b></div>
</div></div>

<div class="hl">
  <b>三条判据</b><br>
  ① 四片桨的风都朝<i>下</i>吹（推力向上）<br>
  ② <i>对角同向、相邻反向</i><br>
  ③ 四路同开 3 秒，机身不该自转<br>
  板子只能单向驱动，转向靠换线，软件改不了。<br>
  <span style="color:#6d8098">没自动弹出就打开 <b>192.168.4.1</b>；页面切后台 1.2 秒后电机会自动停。</span>
</div>

<script>
const POS=['左上','右上','左下','右下'];
const $=id=>document.getElementById(id);
const clamp=(v,a,b)=>v<a?a:(v>b?b:v);

for(let i=0;i<4;i++){
  const d=document.createElement('div');
  d.className='m';
  d.innerHTML='<div class="hd"><b>M'+(i+1)+'</b><span>'+POS[i]+'</span></div>'+
    '<div class="pv" id="pv'+i+'">0%</div>'+
    '<button id="bt'+i+'">转一下</button>';
  $('grid').appendChild(d);
}

function clock(){
  const d=new Date();
  const p=n=>String(n).padStart(2,'0');
  return p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());
}
function log(html){
  const el=$('log');
  el.innerHTML=('<div>['+clock()+'] '+html+'</div>')+el.innerHTML;
  if(el.children.length>40) el.removeChild(el.lastChild);
}
function api(q){ return fetch(q,{cache:'no-store'}).catch(()=>{}); }

let jogTimer=[0,0,0,0];
for(let i=0;i<4;i++){
  $('bt'+i).onclick=()=>{
    const b=$('bt'+i);
    if(b.disabled) return;
    api('/api/jog?ch='+(i+1)+'&pm=150&ms=1500');
    log('<b>M'+(i+1)+'</b> '+POS[i]+' 转 1.5s · 15%');
    b.disabled=true; b.classList.add('run'); b.textContent='转动中…';
    clearTimeout(jogTimer[i]);
    jogTimer[i]=setTimeout(()=>{
      b.disabled=false; b.classList.remove('run'); b.textContent='转一下';
    },1550);
  };
}

const ms=$('ms');
let slTimer=0, sling=false;
function pushAll(v){
  api('/api/all?pm='+Math.round(v*10));
}
ms.oninput=()=>{
  const v=+ms.value;
  $('mv').textContent=v+'%';
  sling=true;
  clearTimeout(slTimer);
  slTimer=setTimeout(()=>{ pushAll(v); sling=false; },110);
};
ms.onchange=()=>{ clearTimeout(slTimer); pushAll(+ms.value); sling=false; };

$('stop').onclick=()=>{
  api('/api/stop'); ms.value=0; $('mv').textContent='0%'; log('<i>全部停止</i>');
};
$('zero').onclick=()=>{
  if(+ms.value>0){ log('<i>先归零再标定</i>'); return; }
  api('/api/zero'); log('陀螺零偏标定…');
};

let ramping=false;
$('ramp').onclick=async()=>{
  if(ramping) return;
  ramping=true;
  const b=$('ramp');
  b.disabled=true; b.classList.add('run'); b.textContent='测试中…';
  const steps=[6,9,12,15,18,21,24];
  for(const p of steps){
    if(!ramping) break;
    api('/api/all?pm='+(p*10));
    log('<b>'+p+'%</b> ← 读秤');
    for(let k=0;k<8;k++){
      if(!ramping) break;
      await new Promise(r=>setTimeout(r,500));
      api('/api/all?pm='+(p*10));
    }
  }
  api('/api/all?pm=0');
  log('结束，已归零');
  ramping=false;
  b.disabled=false; b.classList.remove('run'); b.textContent='6 → 24% · 每档 4 秒';
};
$('stop').addEventListener('click',()=>{ ramping=false; });

let fails=0;
async function tick(){
  try{
    const r=await fetch('/api/state',{cache:'no-store'});
    const s=await r.json();
    fails=0;
    $('dot').classList.remove('off');
    $('sBatt').textContent=(s.vb/1000).toFixed(2)+'V';
    $('sSta').textContent=s.cl;
    $('sUp').textContent=Math.floor(s.up/60)+'m'+String(s.up%60).padStart(2,'0')+'s';

    for(let i=0;i<4;i++){
      const pc=Math.round(s.d[i]/10);
      const el=$('pv'+i);
      el.textContent=pc+'%';
      el.classList.toggle('on', pc>0);
    }
    if(!sling && !ramping){
      const avg=(s.d[0]+s.d[1]+s.d[2]+s.d[3])/4/10;
      if(Math.abs(avg-+ms.value)>1.2){ ms.value=Math.round(avg); $('mv').textContent=Math.round(avg)+'%'; }
    }

    const ax=s.ax/1000, ay=s.ay/1000, az=s.az/1000;
    const roll=Math.atan2(ay, az||1e-9)*180/Math.PI;
    const pitch=Math.atan2(-ax, Math.hypot(ay,az)||1e-9)*180/Math.PI;
    $('nRoll').textContent=roll.toFixed(1)+'°';
    $('nPitch').textContent=pitch.toFixed(1)+'°';
    $('nAcc').textContent=Math.hypot(ax,ay,az).toFixed(2)+'g';
    $('bubDot').style.transform='translate('+clamp(roll*2.4,-26,26).toFixed(1)+'px,'+
      clamp(pitch*2.4,-26,26).toFixed(1)+'px)';
  }catch(e){
    if(++fails>5){ $('dot').classList.add('off'); $('sBatt').textContent='断开'; }
  }
  setTimeout(tick,120);
}
tick();
</script>
</body></html>)HTML";

// ------------------------------------------------------------------ HTTP
static void sendJson(const char* s) {
  server.send(200, "application/json; charset=utf-8", s);
}

static void handleState() {
  lastCmdMs = millis();          // 页面在轮询 = 有人在看着，算心跳
  char j[256];
  snprintf(j, sizeof(j),
           "{\"vb\":%lu,\"pg\":%d,\"d\":[%u,%u,%u,%u],"
           "\"ax\":%ld,\"ay\":%ld,\"az\":%ld,\"gx\":%ld,\"gy\":%ld,\"gz\":%ld,"
           "\"cl\":%d,\"up\":%lu,\"imu\":%d}",
           (unsigned long)vbatMv, digitalRead(PIN_PGOOD),
           duty[0], duty[1], duty[2], duty[3],
           (long)mg[0], (long)mg[1], (long)mg[2],
           (long)cd[0], (long)cd[1], (long)cd[2],
           (int)WiFi.softAPgetStationNum(),
           (unsigned long)(millis() / 1000), imuOK ? 1 : 0);
  sendJson(j);
}

static void handleSet() {
  const int ch = server.arg("ch").toInt();
  int pm = server.arg("pm").toInt();
  if (ch < 1 || ch > 4) { server.send(400, "text/plain", "bad ch"); return; }
  if (pm > WEB_CH_MAX) pm = WEB_CH_MAX;
  lastCmdMs = millis();
  setChannel(ch, pm, 0);
  sendJson("{\"ok\":1}");
}

static void handleJog() {
  const int ch = server.arg("ch").toInt();
  int pm = server.arg("pm").toInt();
  int ms = server.arg("ms").toInt();
  if (ch < 1 || ch > 4) { server.send(400, "text/plain", "bad ch"); return; }
  if (pm > WEB_CH_MAX) pm = WEB_CH_MAX;
  if (ms < 20) ms = 20;
  if (ms > 5000) ms = 5000;
  lastCmdMs = millis();
  setChannel(ch, pm, (uint32_t)ms);
  sendJson("{\"ok\":1}");
}

static void handleAll() {
  int pm = server.arg("pm").toInt();
  if (pm > WEB_ALL_MAX) pm = WEB_ALL_MAX;
  pm = clampPm(pm);
  lastCmdMs = millis();
  for (int i = 0; i < 4; i++) { duty[i] = (uint16_t)pm; spinEndMs[i] = 0; }
  applyDuty();
  sendJson("{\"ok\":1}");
}

static void handleStop() {
  lastCmdMs = millis();
  allOff();
  sendJson("{\"ok\":1}");
}

static void handleZero() {
  int sum = duty[0] + duty[1] + duty[2] + duty[3];
  if (sum > 0) { server.send(409, "text/plain", "motors on"); return; }
  float s3[3] = {0, 0, 0};
  int n = 0;
  uint8_t b[12];
  const uint32_t t0 = millis();
  while (millis() - t0 < 600) {
    if (imuR(0x35, b, 12)) {
      s3[0] += (int16_t)(b[7] << 8 | b[6]);
      s3[1] += (int16_t)(b[9] << 8 | b[8]);
      s3[2] += (int16_t)(b[11] << 8 | b[10]);
      n++;
    }
  }
  if (n > 10) {
    for (int i = 0; i < 3; i++) gOff[i] = s3[i] / (float)n;
    gOffValid = true;
    char j[96];
    snprintf(j, sizeof(j), "{\"ok\":1,\"o\":[%.1f,%.1f,%.1f]}", gOff[0], gOff[1], gOff[2]);
    lastCmdMs = millis();
    sendJson(j);
  } else {
    server.send(500, "text/plain", "zero fail");
  }
}

// 其它任何路径（含各系统的联网探测点）一律 302 回首页，触发“登录网络”弹窗
static void handleNotFound() {
  server.sendHeader("Location", String("http://") + WiFi.softAPIP().toString() + "/", true);
  server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  server.send(302, "text/plain", "");
}

// ------------------------------------------------------------------ serial
static void sendVer() {
  uint8_t mac[6];
  esp_efuse_mac_get_default(mac);
  // 注意：v6 起 D 帧里的 vbat 已经是乘过 VBAT_DIV 的电芯电压，
  // 所以这里的 div 报 1.0，页面不要再乘一次（旧页面按 div 换算，否则会翻倍成 8.3V）
  Serial.printf("#VER,%s,%02X:%02X:%02X:%02X:%02X:%02X,imu=0x%02X,div=1.0,dutymax=%d,wd=%d\n",
                FW_VER, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5],
                (unsigned)IMU, DUTY_MAX, (int)WD_MS);
  Serial.printf("#WIFI,ssid=%s,open,ip=%s,http://%s/\n",
                AP_SSID, WiFi.softAPIP().toString().c_str(), WiFi.softAPIP().toString().c_str());
}

static void handleLine(char* s) {
  lastCmdMs = millis();
  if (!s[0]) return;
  const char c = s[0];

  if (c == 'K') return;
  if (c == 'X') { allOff(); Serial.println("#ACK,STOP"); return; }
  if (c == 'A') { Serial.println("#ACK,NO_LOCK"); return; }
  if (c == 'V') { sendVer(); return; }

  if (c == 'P') {
    int ch = 0, pm = 0;
    if (sscanf(s, "P,%d,%d", &ch, &pm) == 2 && ch >= 1 && ch <= 4) {
      setChannel(ch, pm, 0);
      Serial.printf("#ACK,P,%d,%d\n", ch, duty[ch - 1]);
    }
    return;
  }
  if (c == 'B') {
    int pm = 0;
    if (sscanf(s, "B,%d", &pm) == 1) {
      pm = clampPm(pm);
      for (int i = 0; i < 4; i++) { duty[i] = (uint16_t)pm; spinEndMs[i] = 0; }
      applyDuty();
      Serial.printf("#ACK,B,%d\n", pm);
    }
    return;
  }
  if (c == 'T') {
    int ch = 0, pm = 0, ms = 0;
    if (sscanf(s, "T,%d,%d,%d", &ch, &pm, &ms) == 3 && ch >= 1 && ch <= 4) {
      if (ms > 5000) ms = 5000;
      if (ms < 20)   ms = 20;
      setChannel(ch, pm, (uint32_t)ms);
      Serial.printf("#ACK,T,%d,%d,%d\n", ch, duty[ch - 1], ms);
    }
    return;
  }
  if (c == 'R') {
    if (duty[0] || duty[1] || duty[2] || duty[3]) { Serial.println("#ERR,MOTORS_ON"); return; }
    float s3[3] = {0, 0, 0};
    int n = 0;
    uint8_t b[12];
    const uint32_t t0 = millis();
    while (millis() - t0 < 600) {
      if (imuR(0x35, b, 12)) {
        s3[0] += (int16_t)(b[7] << 8 | b[6]);
        s3[1] += (int16_t)(b[9] << 8 | b[8]);
        s3[2] += (int16_t)(b[11] << 8 | b[10]);
        n++;
      }
    }
    if (n > 10) {
      for (int i = 0; i < 3; i++) gOff[i] = s3[i] / (float)n;
      gOffValid = true;
      Serial.printf("#ACK,ZERO,%.1f,%.1f,%.1f\n", gOff[0], gOff[1], gOff[2]);
    } else Serial.println("#ERR,ZERO_FAIL");
    return;
  }
}

// ------------------------------------------------------------------ setup
void setup() {
  for (int i = 0; i < 4; i++) {
    pinMode(PIN_PWM[i], OUTPUT);
    digitalWrite(PIN_PWM[i], LOW);
  }
  delay(2);
  for (int i = 0; i < 4; i++) { ledcAttach(PIN_PWM[i], 20000, 10); ledcWrite(PIN_PWM[i], 0); }
  allOff();

  Serial.begin(115200);
  delay(200);

  Wire.begin(PIN_SDA, PIN_SCL, 400000);
  Wire.setClock(400000);
  imuOK = imuInit();

  pinMode(PIN_PGOOD, INPUT);
  pinMode(PIN_VBAT, INPUT);
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);

  {
    uint8_t b[12];
    const uint32_t t0 = micros();
    int n = 0;
    for (int i = 0; i < 600; i++) if (imuR(0x35, b, 12)) n++;
    const uint32_t dt = micros() - t0;
    if (dt > 0 && n > 10) fsMeas = (float)n * 1000000.0f / (float)dt;
  }
  rebuildFilters();

  // ---- 热点：开放网络，无密码 ----
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP);
  IPAddress ip(192, 168, 4, 1), gw(192, 168, 4, 1), mask(255, 255, 255, 0);
  WiFi.softAPConfig(ip, gw, mask);
  WiFi.softAP(AP_SSID, NULL, AP_CH, 0, 4);
  delay(160);
  dns.setErrorReplyCode(DNSReplyCode::NoError);
  dns.start(53, "*", WiFi.softAPIP());

  // ---- 路由 ----
  server.on("/", []() { server.send_P(200, "text/html; charset=utf-8", PAGE_HTML); });
  server.on("/api/state", handleState);
  server.on("/api/set", handleSet);
  server.on("/api/jog", handleJog);
  server.on("/api/all", handleAll);
  server.on("/api/stop", handleStop);
  server.on("/api/zero", handleZero);
  server.onNotFound(handleNotFound);
  server.begin();

  Serial.println();
  Serial.println("#BOOT,ESP32-1S-Basic-R4-E07," FW_VER ",AP_MODE,4CH,HIRATE");
  sendVer();
  if (!imuOK) Serial.println("#ERR,IMU_INIT");
  if (WiFi.softAPIP() != ip) Serial.println("#ERR,AP_FAIL");
  lastCmdMs = millis();
}

// ------------------------------------------------------------------ loop
void loop() {
  const uint32_t now = millis();

  // ---- DNS 劫持 + HTTP：每次 loop 都喂一次，保证手机端不卡 ----
  dns.processNextRequest();
  server.handleClient();

  // ---- 串口 ----
  while (Serial.available()) {
    const char ch = (char)Serial.read();
    if (ch == '\n' || ch == '\r') { rxBuf[rxLen] = 0; if (rxLen) handleLine(rxBuf); rxLen = 0; }
    else if (rxLen < sizeof(rxBuf) - 1) rxBuf[rxLen++] = ch;
  }

  // ---- IMU：限到 1 kHz，留时间给 WiFi ----
  if (micros() - lastImuUs >= 1000) {
    lastImuUs = micros();
    uint8_t b[12];
    if (imuR(0x35, b, 12)) {
      const float A[3] = {
        (float)(int16_t)(b[1] << 8 | b[0]),
        (float)(int16_t)(b[3] << 8 | b[2]),
        (float)(int16_t)(b[5] << 8 | b[4])
      };
      const float G[3] = {
        (float)(int16_t)(b[7] << 8 | b[6]),
        (float)(int16_t)(b[9] << 8 | b[8]),
        (float)(int16_t)(b[11] << 8 | b[10])
      };
      for (int i = 0; i < 3; i++) {
        welford(&stDa[i], lpfStep(&fA[i], A[i]));
        welford(&stDg[i], lpfStep(&fG[i], G[i]));
      }
    } else i2cFail++;
  }

  // ---- 20 ms 汇总一帧 ----
  static uint32_t lastD = 0;
  if (now - lastD >= 20) {
    lastD = now;

    static uint32_t vbatAcc = 0; static int vbatN = 0;
    vbatAcc += analogReadMilliVolts(PIN_VBAT);
    if (++vbatN >= 5) { vbatMv = (uint32_t)(vbatAcc / 5.0f * VBAT_DIV); vbatAcc = 0; vbatN = 0; }

    float m[3], gg[3];
    for (int i = 0; i < 3; i++) { m[i] = stDa[i].mean; gg[i] = stDg[i].mean; }
    for (int i = 0; i < 3; i++) { welfordReset(&stDa[i]); welfordReset(&stDg[i]); }

    if (gOffValid) for (int i = 0; i < 3; i++) gg[i] -= gOff[i];

    for (int i = 0; i < 3; i++) {
      mg[i] = (int32_t)(m[i] * 1000.0f / 4096.0f);
      cd[i] = (int32_t)(gg[i] * 100.0f / 64.0f);
    }

    Serial.printf("D,%lu,%lu,%d,%ld,%ld,%ld,%ld,%ld,%ld,%u,%u,%u,%u,%d,%d\n",
                  (unsigned long)now, (unsigned long)vbatMv, digitalRead(PIN_PGOOD),
                  (long)mg[0], (long)mg[1], (long)mg[2],
                  (long)cd[0], (long)cd[1], (long)cd[2],
                  duty[0], duty[1], duty[2], duty[3], 1, (int)(i2cFail ? 1 : 0));
  }

  // ---- 定时点动收尾 ----
  bool ended = false;
  for (int i = 0; i < 4; i++) {
    if (spinEndMs[i] && (int32_t)(now - spinEndMs[i]) >= 0) {
      duty[i] = 0; spinEndMs[i] = 0; ended = true;
    }
  }
  if (ended) applyDuty();

  // ---- 看门狗 ----
  // 注意：必须用有符号差值。命令是在本次 loop 里更新的，lastCmdMs 可能比循环开头的
  // now 还新，无符号相减会下溢成 43 亿，"超时"恒成立，导致每发一次命令就秒清一次。
  const uint32_t sum = (uint32_t)duty[0] + duty[1] + duty[2] + duty[3];
  if (sum > 0 && (int32_t)(millis() - lastCmdMs) > (int32_t)WD_MS) {
    allOff();
    wdTrips++;
    Serial.println("#ERR,WATCHDOG");
  }
}
