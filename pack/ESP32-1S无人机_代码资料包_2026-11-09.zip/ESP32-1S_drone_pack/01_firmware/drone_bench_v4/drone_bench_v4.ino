/*
 * ESP32-1S-Basic-R4-E07  bench telemetry firmware  (v4)
 *
 * v3 -> v4 的改动（按实机情况放开限制）：
 *   - 删除 arm/disarm 状态机：上电即可输出，不再需要"按住 1.2 秒解锁"
 *     原因：v3 的握手在网络/串口延迟下会出现"已解锁 + 固件侧已上锁"的错位日志，
 *     且电机是 CJ3400 小有刷，堵转也伤不到人。
 *   - 删除单通道限制：四路可以同时给，方便后面测四点升力/差速
 *   - 上限从 300‰ 放到 1000‰（100%）
 *   - 保留 1200 ms 指令看门狗：只要有一路非零，超过 1200 ms 收不到任何指令
 *     就全部归零。目的是防止"关掉页面/拔掉 USB 后电机一直转"。
 *
 * 上行 50 Hz：
 *   D,<ms>,<vbat_mV>,<pgood>,<ax>,<ay>,<az>,<gx>,<gy>,<gz>,<d1>,<d2>,<d3>,<d4>,<en>,<err>
 *     ax/ay/az 单位 mg，gx/gy/gz 单位 0.01 dps，d1..d4 单位 ‰
 *     en 恒为 1（v3 的 armed 位，留给旧版页面兼容）
 *     err 位: 1=IMU 无响应 2=VBAT 越界 4=看门狗触发过 8=ADC 未就绪
 *
 * 下行命令：
 *   P,<ch>,<permille>      设定某一路（ch=1..4），不影响其它路
 *   B,<permille>           四路同时设成同一个值
 *   T,<ch>,<permille>,<ms> 定时点动，到时间自动归零（ms ≤ 5000）
 *   X                      全部归零
 *   K                      心跳（页面每 200 ms 发一次）
 *   R                      陀螺零偏标定（要求四路为 0）
 *   V                      回一帧 #VER
 *
 * 引脚（从 R4-E07 网表解析）：
 *   PWM1..4 = GPIO4/5/6/7   IMU_SDA=GPIO10  IMU_SCL=GPIO11
 *   VBAT_ADC=GPIO2（100k/100k 分压 ×2）  USB_PGOOD_N=GPIO9  IMU_INT=GPIO12
 */

#include <Wire.h>
#include <Arduino.h>
#include <esp_mac.h>

#define FW_VER "v4-free"

static const int PIN_PWM[4] = {4, 5, 6, 7};
static const int PIN_SDA = 10, PIN_SCL = 11, PIN_INT = 12;
static const int PIN_VBAT = 2, PIN_PGOOD = 9;

static const uint8_t IMU = 0x6B;          // 实测地址（图纸标 0x6A）
static const float VBAT_DIV = 2.0f;
static const int   DUTY_MAX = 1000;       // ‰ 上限 100%
static const uint32_t WD_MS = 1200;       // 有输出时的心跳超时

static uint16_t duty[4] = {0, 0, 0, 0};
static uint32_t lastCmdMs = 0;
static uint32_t spinEndMs[4] = {0, 0, 0, 0};
static uint32_t wdTrips = 0;
static bool     wdArmed = true;           // 只要有一路非零就参与看门狗

static float gOff[3] = {0, 0, 0};         // 陀螺零偏 (raw counts)
static bool  gOffValid = false;

static char rxBuf[64];
static uint8_t rxLen = 0;

// ------------------------------------------------------------------ motor
static void applyDuty() {
  for (int i = 0; i < 4; i++) {
    ledcWrite(PIN_PWM[i], (uint32_t)duty[i] * 1023u / 1000u);
  }
}

static void allOff() {
  for (int i = 0; i < 4; i++) { duty[i] = 0; spinEndMs[i] = 0; }
  applyDuty();
}

static int clampPm(int pm) {
  if (pm < 0) return 0;
  if (pm > DUTY_MAX) return DUTY_MAX;
  return pm;
}

static void setChannel(int ch, int permille, uint32_t ms) {
  if (ch < 1 || ch > 4) return;
  duty[ch - 1] = (uint16_t)clampPm(permille);
  spinEndMs[ch - 1] = ms ? (millis() + ms) : 0;
  applyDuty();
}

// ------------------------------------------------------------------ IMU
static bool imuW(uint8_t reg, uint8_t v) {
  Wire.beginTransmission(IMU); Wire.write(reg); Wire.write(v);
  return Wire.endTransmission() == 0;
}
static bool imuR(uint8_t reg, uint8_t* b, uint8_t n) {
  Wire.beginTransmission(IMU); Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)IMU, (int)n) != n) return false;
  for (uint8_t i = 0; i < n; i++) b[i] = Wire.read();
  return true;
}

static bool imuInit() {
  uint8_t who = 0;
  if (!imuR(0x00, &who, 1) || who != 0x05) return false;
  imuW(0x02, 0x40);   // CTRL1 地址自增
  imuW(0x03, 0x24);   // CTRL2 accel ±8g  (4096 LSB/g)
  imuW(0x04, 0x54);   // CTRL3 gyro ±512dps (64 LSB/dps)
  imuW(0x08, 0x03);   // CTRL7 accel+gyro 使能
  delay(120);
  return true;
}

// ------------------------------------------------------------------ TX
static void sendVer() {
  uint8_t mac[6];
  esp_efuse_mac_get_default(mac);
  Serial.printf("#VER,%s,%02X:%02X:%02X:%02X:%02X:%02X,imu=0x%02X,div=%d,dutymax=%d,wd=%d\n",
                FW_VER,
                mac[0], mac[1], mac[2], mac[3], mac[4], mac[5],
                (unsigned)IMU, (int)VBAT_DIV, DUTY_MAX, (int)WD_MS);
}

// ------------------------------------------------------------------ cmd
static void handleLine(char* s) {
  lastCmdMs = millis();
  if (!s[0]) return;
  char c = s[0];

  if (c == 'K') return;
  if (c == 'X') { allOff(); Serial.println("#ACK,STOP"); return; }
  if (c == 'A') { Serial.println("#ACK,NO_LOCK"); return; }   // 兼容旧页面
  if (c == 'V') { sendVer(); return; }

  if (c == 'P') {
    int ch = 0, pm = 0;
    if (sscanf(s, "P,%d,%d", &ch, &pm) == 2 && ch >= 1 && ch <= 4) {
      setChannel(ch, pm, 0);
      Serial.printf("#ACK,P,%d,%d\n", ch, duty[ch - 1]);
    }
    return;
  }
  if (c == 'B') {
    int pm = 0;
    if (sscanf(s, "B,%d", &pm) == 1) {
      pm = clampPm(pm);
      for (int i = 0; i < 4; i++) { duty[i] = (uint16_t)pm; spinEndMs[i] = 0; }
      applyDuty();
      Serial.printf("#ACK,B,%d\n", pm);
    }
    return;
  }
  if (c == 'T') {
    int ch = 0, pm = 0, ms = 0;
    if (sscanf(s, "T,%d,%d,%d", &ch, &pm, &ms) == 3 && ch >= 1 && ch <= 4) {
      if (ms > 5000) ms = 5000;
      if (ms < 20)   ms = 20;
      setChannel(ch, pm, (uint32_t)ms);
      Serial.printf("#ACK,T,%d,%d,%d\n", ch, duty[ch - 1], ms);
    }
    return;
  }
  if (c == 'R') {
    if (duty[0] || duty[1] || duty[2] || duty[3]) { Serial.println("#ERR,MOTORS_ON"); return; }
    uint8_t b[12]; float s3[3] = {0, 0, 0}; int n = 0;
    uint32_t t0 = millis();
    while (millis() - t0 < 600) {
      if (imuR(0x35, b, 12)) {
        s3[0] += (int16_t)(b[7] << 8 | b[6]);
        s3[1] += (int16_t)(b[9] << 8 | b[8]);
        s3[2] += (int16_t)(b[11] << 8 | b[10]);
        n++;
      }
      delay(10);
    }
    if (n > 10) {
      for (int i = 0; i < 3; i++) gOff[i] = s3[i] / n;
      gOffValid = true;
      Serial.printf("#ACK,ZERO,%.1f,%.1f,%.1f\n", gOff[0], gOff[1], gOff[2]);
    } else Serial.println("#ERR,ZERO_FAIL");
    return;
  }
}

// ------------------------------------------------------------------ setup
void setup() {
  // 先拉低再挂 PWM：保证上电瞬间不会给电机任何电平
  for (int i = 0; i < 4; i++) {
    pinMode(PIN_PWM[i], OUTPUT);
    digitalWrite(PIN_PWM[i], LOW);
  }
  delay(2);
  for (int i = 0; i < 4; i++) {
    ledcAttach(PIN_PWM[i], 20000, 10);   // 20 kHz，10 bit
    ledcWrite(PIN_PWM[i], 0);
  }
  allOff();

  Serial.begin(115200);
  delay(300);

  Wire.begin(PIN_SDA, PIN_SCL, 400000);
  bool imuOK = imuInit();
  pinMode(PIN_PGOOD, INPUT);
  pinMode(PIN_VBAT, INPUT);
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);

  Serial.println();
  Serial.println("#BOOT,ESP32-1S-Basic-R4-E07," FW_VER ",NO_LOCK,4CH");
  Serial.println("#NOTE,no arm needed, 4 channels independent, max 1000 permille, watchdog 1200ms");
  sendVer();
  if (!imuOK) Serial.println("#ERR,IMU_INIT");
  lastCmdMs = millis();
}

// ------------------------------------------------------------------ loop
void loop() {
  uint32_t now = millis();

  // ---- 串口收命令 ----
  while (Serial.available()) {
    char ch = (char)Serial.read();
    if (ch == '\n' || ch == '\r') { rxBuf[rxLen] = 0; if (rxLen) handleLine(rxBuf); rxLen = 0; }
    else if (rxLen < sizeof(rxBuf) - 1) rxBuf[rxLen++] = ch;
  }

  // ---- 定时点动到点归零 ----
  bool ended = false;
  for (int i = 0; i < 4; i++) {
    if (spinEndMs[i] && (int32_t)(now - spinEndMs[i]) >= 0) {
      duty[i] = 0; spinEndMs[i] = 0; ended = true;
      Serial.printf("#ACK,T_END,%d\n", i + 1);
    }
  }
  if (ended) applyDuty();

  // ---- 看门狗：有输出却收不到指令 ----
  uint32_t sum = (uint32_t)duty[0] + duty[1] + duty[2] + duty[3];
  if (sum > 0 && (now - lastCmdMs) > WD_MS) {
    allOff(); wdTrips++;
    Serial.println("#ERR,WATCHDOG");
  }

  // ---- 50 Hz 上报 ----
  static uint32_t lastTx = 0;
  if (now - lastTx >= 20) {
    lastTx = now;
    uint8_t b[12] = {0};
    int errBits = 0;
    int16_t ax = 0, ay = 0, az = 0, gx = 0, gy = 0, gz = 0;
    if (imuR(0x35, b, 12)) {
      ax = (int16_t)(b[1] << 8 | b[0]);
      ay = (int16_t)(b[3] << 8 | b[2]);
      az = (int16_t)(b[5] << 8 | b[4]);
      gx = (int16_t)(b[7] << 8 | b[6]);
      gy = (int16_t)(b[9] << 8 | b[8]);
      gz = (int16_t)(b[11] << 8 | b[10]);
      if (gOffValid) { gx -= (int16_t)gOff[0]; gy -= (int16_t)gOff[1]; gz -= (int16_t)gOff[2]; }
    } else errBits |= 1;

    static uint32_t vbatAcc = 0; static int vbatN = 0; static uint32_t vbatMv = 0;
    vbatAcc += analogReadMilliVolts(PIN_VBAT); vbatN++;
    if (vbatN >= 10) { vbatMv = vbatAcc / vbatN; vbatAcc = 0; vbatN = 0; }
    if (vbatMv > 4600 || (vbatMv > 0 && vbatMv < 1500)) errBits |= 2;
    if (wdTrips) errBits |= 4;

    // mg / 0.01dps
    int32_t mg_x = (int32_t)ax * 1000 / 4096;
    int32_t mg_y = (int32_t)ay * 1000 / 4096;
    int32_t mg_z = (int32_t)az * 1000 / 4096;
    int32_t cd_x = (int32_t)gx * 100 / 64;
    int32_t cd_y = (int32_t)gy * 100 / 64;
    int32_t cd_z = (int32_t)gz * 100 / 64;

    Serial.printf("D,%lu,%lu,%d,%ld,%ld,%ld,%ld,%ld,%ld,%u,%u,%u,%u,%d,%d\n",
                  (unsigned long)now, (unsigned long)vbatMv, digitalRead(PIN_PGOOD),
                  (long)mg_x, (long)mg_y, (long)mg_z,
                  (long)cd_x, (long)cd_y, (long)cd_z,
                  duty[0], duty[1], duty[2], duty[3], 1, errBits);
  }
}
