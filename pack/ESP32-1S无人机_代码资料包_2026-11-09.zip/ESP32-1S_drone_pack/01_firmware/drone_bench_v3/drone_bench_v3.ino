/*
 * ESP32-1S-Basic-R4-E07  bench bring-up + telemetry firmware  (v3)
 *
 * 与 v2 的区别（接上电池/电机之后必须换）：
 *   - 启动即 DISARM，四路 PWM 恒 0
 *   - 单通道限制：任何时刻最多一路非零，设第二路会自动清掉第一路
 *   - 硬限幅 300‰（30%），主机怎么发都不会超
 *   - 看门狗：armed 状态下 700 ms 没收到心跳/指令 -> 立刻全部归零并 disarm
 *   - 不再有任何"上拉探测/拉高互串"的动作，绝不会意外给电机加速
 *
 * 上行 50 Hz：
 *   D,<ms>,<vbat_mV>,<pgood>,<ax>,<ay>,<az>,<gx>,<gy>,<gz>,<d1>,<d2>,<d3>,<d4>,<arm>,<err>
 *     ax/ay/az 单位 mg，gx/gy/gz 单位 0.01 dps，d1..d4 单位 ‰
 *     err 位: 1=IMU 无响应 2=VBAT 越界 4=看门狗触发过 8=ADC 未就绪
 *
 * 下行命令：
 *   A                      arm（只允许输出，不自动给油门）
 *   X                      disarm + 全部归零
 *   K                      心跳，armed 时每 200 ms 发一次
 *   P,<ch>,<permille>      设定某一路（ch=1..4），自动清掉其它路
 *   T,<ch>,<permille>,<ms> 定时点动，到时间自动归零
 *   R                      零偏标定（要求四路为 0，静止 600 ms 内不许动）
 *   V                      回一帧 #VER
 *
 * 引脚（从 R4-E07 网表解析）：
 *   PWM1..4 = GPIO4/5/6/7   IMU_SDA=GPIO10  IMU_SCL=GPIO11
 *   VBAT_ADC=GPIO2（100k/100k 分压 ×2）  USB_PGOOD_N=GPIO9  IMU_INT=GPIO12
 */

#include <Wire.h>
#include <Arduino.h>
#include <esp_mac.h>

#define FW_VER "v3-bench"

static const int PIN_PWM[4] = {4, 5, 6, 7};
static const int PIN_SDA = 10, PIN_SCL = 11, PIN_INT = 12;
static const int PIN_VBAT = 2, PIN_PGOOD = 9;

static const uint8_t IMU = 0x6B;          // 实测地址（图纸标 0x6A）
static const float VBAT_DIV = 2.0f;
static const int   DUTY_MAX = 300;        // ‰ 硬上限 30%

static uint16_t duty[4] = {0, 0, 0, 0};
static bool     armed = false;
static uint32_t lastCmdMs = 0;
static uint32_t spinEndMs[4] = {0, 0, 0, 0};
static uint16_t spinDuty[4] = {0, 0, 0, 0};
static uint32_t wdTrips = 0;

static float gOff[3] = {0, 0, 0};         // 陀螺零偏 (raw counts)
static bool  gOffValid = false;

static char rxBuf[64];
static uint8_t rxLen = 0;

// ------------------------------------------------------------------ motor
static void applyDuty() {
  for (int i = 0; i < 4; i++) {
    uint32_t d = (uint32_t)duty[i] * 1023u / 1000u;
    ledcWrite(PIN_PWM[i], armed ? d : 0);
  }
}

static void allOff() {
  for (int i = 0; i < 4; i++) { duty[i] = 0; spinDuty[i] = 0; spinEndMs[i] = 0; }
  applyDuty();
}

static void setChannel(int ch, int permille, uint32_t ms) {
  if (ch < 1 || ch > 4) return;
  if (permille < 0) permille = 0;
  if (permille > DUTY_MAX) permille = DUTY_MAX;
  // 单通道限制：其它路强制归零
  for (int i = 0; i < 4; i++) {
    if (i != ch - 1) { duty[i] = 0; spinDuty[i] = 0; spinEndMs[i] = 0; }
  }
  duty[ch - 1] = (uint16_t)permille;
  if (ms) { spinDuty[ch - 1] = (uint16_t)permille; spinEndMs[ch - 1] = millis() + ms; }
  else    { spinDuty[ch - 1] = 0; spinEndMs[ch - 1] = 0; }
  applyDuty();
}

// ------------------------------------------------------------------ IMU
static bool imuW(uint8_t reg, uint8_t v) {
  Wire.beginTransmission(IMU); Wire.write(reg); Wire.write(v);
  return Wire.endTransmission() == 0;
}
static bool imuR(uint8_t reg, uint8_t* b, uint8_t n) {
  Wire.beginTransmission(IMU); Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)IMU, (int)n) != n) return false;
  for (uint8_t i = 0; i < n; i++) b[i] = Wire.read();
  return true;
}

static bool imuInit() {
  uint8_t who = 0;
  if (!imuR(0x00, &who, 1) || who != 0x05) return false;
  imuW(0x02, 0x40);   // CTRL1 地址自增
  imuW(0x03, 0x24);   // CTRL2 accel ±8g  (4096 LSB/g)
  imuW(0x04, 0x54);   // CTRL3 gyro ±512dps (64 LSB/dps)
  imuW(0x08, 0x03);   // CTRL7 accel+gyro 使能
  delay(120);
  return true;
}

// ------------------------------------------------------------------ TX
static void sendVer() {
  uint8_t mac[6];
  esp_efuse_mac_get_default(mac);
  Serial.printf("#VER,%s,%02X:%02X:%02X:%02X:%02X:%02X,imu=0x%02X,div=%d,dutymax=%d\n",
                FW_VER,
                mac[0], mac[1], mac[2], mac[3], mac[4], mac[5],
                (unsigned)IMU, (int)VBAT_DIV, DUTY_MAX);
}

// ------------------------------------------------------------------ cmd
static void handleLine(char* s) {
  lastCmdMs = millis();
  if (!s[0]) return;
  char c = s[0];
  if (c == 'A') { armed = true; allOff(); Serial.println("#ACK,ARM"); return; }
  if (c == 'X') { armed = false; allOff(); Serial.println("#ACK,DISARM"); return; }
  if (c == 'K') { return; }
  if (c == 'V') { sendVer(); return; }
  if (c == 'P') {
    int ch = 0, pm = 0;
    if (sscanf(s, "P,%d,%d", &ch, &pm) == 2) {
      setChannel(ch, pm, 0);
      Serial.printf("#ACK,P,%d,%d\n", ch, duty[ch - 1]);
    }
    return;
  }
  if (c == 'T') {
    int ch = 0, pm = 0, ms = 0;
    if (sscanf(s, "T,%d,%d,%d", &ch, &pm, &ms) == 3) {
      if (ms > 3000) ms = 3000;
      setChannel(ch, pm, (uint32_t)ms);
      Serial.printf("#ACK,T,%d,%d,%d\n", ch, duty[ch - 1], ms);
    }
    return;
  }
  if (c == 'R') {
    if (duty[0] || duty[1] || duty[2] || duty[3]) { Serial.println("#ERR,MOTORS_ON"); return; }
    uint8_t b[12]; float s[3] = {0, 0, 0}; int n = 0;
    uint32_t t0 = millis();
    while (millis() - t0 < 600) {
      if (imuR(0x35, b, 12)) {
        s[0] += (int16_t)(b[7] << 8 | b[6]);
        s[1] += (int16_t)(b[9] << 8 | b[8]);
        s[2] += (int16_t)(b[11] << 8 | b[10]);
        n++;
      }
      delay(10);
    }
    if (n > 10) {
      for (int i = 0; i < 3; i++) gOff[i] = s[i] / n;
      gOffValid = true;
      Serial.printf("#ACK,ZERO,%.1f,%.1f,%.1f\n", gOff[0], gOff[1], gOff[2]);
    } else Serial.println("#ERR,ZERO_FAIL");
    return;
  }
}

// ------------------------------------------------------------------ setup
void setup() {
  for (int i = 0; i < 4; i++) {
    ledcAttach(PIN_PWM[i], 20000, 10);   // 20 kHz，10 bit
    ledcWrite(PIN_PWM[i], 0);
    pinMode(PIN_PWM[i], OUTPUT);
    digitalWrite(PIN_PWM[i], LOW);
  }
  armed = false;
  allOff();

  Serial.begin(115200);
  delay(300);

  Wire.begin(PIN_SDA, PIN_SCL, 400000);
  bool imuOK = imuInit();
  pinMode(PIN_PGOOD, INPUT);
  pinMode(PIN_VBAT, INPUT);
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);

  Serial.println();
  Serial.println("#BOOT,ESP32-1S-Basic-R4-E07," FW_VER ",MOTORS_OFF,DISARMED");
  Serial.println("#NOTE,max 300 permille, single channel only, watchdog 700ms");
  sendVer();
  if (!imuOK) Serial.println("#ERR,IMU_INIT");
  lastCmdMs = millis();
}

// ------------------------------------------------------------------ loop
void loop() {
  uint32_t now = millis();

  // ---- 串口收命令 ----
  while (Serial.available()) {
    char ch = (char)Serial.read();
    if (ch == '\n' || ch == '\r') { rxBuf[rxLen] = 0; if (rxLen) handleLine(rxBuf); rxLen = 0; }
    else if (rxLen < sizeof(rxBuf) - 1) rxBuf[rxLen++] = ch;
  }

  // ---- 定时点动到点归零 ----
  for (int i = 0; i < 4; i++) {
    if (spinEndMs[i] && (int32_t)(now - spinEndMs[i]) >= 0) {
      duty[i] = 0; spinEndMs[i] = 0; applyDuty();
      Serial.printf("#ACK,T_END,%d\n", i + 1);
    }
  }

  // ---- 看门狗 ----
  if (armed && duty[0] + duty[1] + duty[2] + duty[3] > 0 && (now - lastCmdMs) > 700) {
    armed = false; allOff(); wdTrips++;
    Serial.println("#ERR,WATCHDOG");
  }

  // ---- 50 Hz 上报 ----
  static uint32_t lastTx = 0;
  if (now - lastTx >= 20) {
    lastTx = now;
    uint8_t b[12] = {0};
    int errBits = 0;
    int16_t ax = 0, ay = 0, az = 0, gx = 0, gy = 0, gz = 0;
    if (imuR(0x35, b, 12)) {
      ax = (int16_t)(b[1] << 8 | b[0]);
      ay = (int16_t)(b[3] << 8 | b[2]);
      az = (int16_t)(b[5] << 8 | b[4]);
      gx = (int16_t)(b[7] << 8 | b[6]);
      gy = (int16_t)(b[9] << 8 | b[8]);
      gz = (int16_t)(b[11] << 8 | b[10]);
      if (gOffValid) { gx -= (int16_t)gOff[0]; gy -= (int16_t)gOff[1]; gz -= (int16_t)gOff[2]; }
    } else errBits |= 1;

    static uint32_t vbatAcc = 0; static int vbatN = 0; static uint32_t vbatMv = 0;
    vbatAcc += analogReadMilliVolts(PIN_VBAT); vbatN++;
    if (vbatN >= 10) { vbatMv = vbatAcc / vbatN; vbatAcc = 0; vbatN = 0; }
    if (vbatMv > 4600 || (vbatMv > 0 && vbatMv < 1500)) errBits |= 2;
    if (wdTrips) errBits |= 4;

    // mg / 0.01dps
    int32_t mg_x = (int32_t)ax * 1000 / 4096;
    int32_t mg_y = (int32_t)ay * 1000 / 4096;
    int32_t mg_z = (int32_t)az * 1000 / 4096;
    int32_t cd_x = (int32_t)gx * 100 / 64;
    int32_t cd_y = (int32_t)gy * 100 / 64;
    int32_t cd_z = (int32_t)gz * 100 / 64;

    Serial.printf("D,%lu,%lu,%d,%ld,%ld,%ld,%ld,%ld,%ld,%u,%u,%u,%u,%d,%d\n",
                  (unsigned long)now, (unsigned long)vbatMv, digitalRead(PIN_PGOOD),
                  (long)mg_x, (long)mg_y, (long)mg_z,
                  (long)cd_x, (long)cd_y, (long)cd_z,
                  duty[0], duty[1], duty[2], duty[3], armed ? 1 : 0, errBits);
  }
}
