/* USB 直连适配层：把页面里的 fetch('/api/...') 翻译成串口指令。
 * 只在本地文件（web_flight/index.html）里存在，固件内嵌页没有这段。 */
(function () {
  var port = null, connected = false, rdr = null, wq = Promise.resolve();
  var lastState = null, paramRes = null;
  var enc = new TextEncoder();
  var link = document.getElementById('link');

  function say(t, k, tt) {
    try { window.dispatchEvent(new CustomEvent('netsay', { detail: { t: t, k: k || '', toast: !!tt } })); } catch (e) {}
  }

  function wline(s) {
    if (!connected) return;
    wq = wq.then(async function () {
      try {
        var w = port.writable.getWriter();
        await w.write(enc.encode(s + '\n'));
        w.releaseLock();
      } catch (e) {}
    });
    return wq;
  }

  function onLine(ln) {
    if (ln.indexOf('#S,') === 0) { try { lastState = JSON.parse(ln.slice(3)); } catch (e) {} return; }
    if (ln.indexOf('#PARAMS,') === 0) {
      if (paramRes) { var f = paramRes; paramRes = null; try { f(JSON.parse(ln.slice(8))); } catch (e) { f(null); } }
      return;
    }
    if (ln.indexOf('#ERR,') === 0) { say(ln.slice(5), 'e', true); return; }
    if (ln.indexOf('#ACK,') === 0) { say(ln.slice(5)); return; }
  }

  async function readLoop() {
    var buf = '';
    while (connected && port && port.readable) {
      rdr = port.readable.getReader();
      try {
        for (;;) {
          var r = await rdr.read();
          if (r.done) break;
          buf += new TextDecoder().decode(r.value, { stream: true });
          var i;
          while ((i = buf.indexOf('\n')) >= 0) {
            var l = buf.slice(0, i).replace(/\r$/, '');
            buf = buf.slice(i + 1);
            if (l) onLine(l);
          }
        }
      } catch (e) {}
      try { rdr.releaseLock(); } catch (e) {}
    }
  }

  function askParams() {
    return new Promise(function (res) {
      paramRes = res;
      wline('C');
      setTimeout(function () { if (paramRes === res) { paramRes = null; res(null); } }, 900);
    });
  }

  function paint(on) { link.textContent = on ? '断开' : '连接串口'; }

  async function connect() {
    if (!('serial' in navigator)) { say('这个浏览器不支持 Web Serial，请用 Chrome / Edge 打开', 'e', true); return; }
    link.disabled = true; link.textContent = '选择中…';
    try {
      port = await navigator.serial.requestPort();
      await port.open({ baudRate: 115200 });
    } catch (e) {
      link.disabled = false; paint(false);
      say('打开串口失败：' + e.message, 'e', true);
      return;
    }
    connected = true;
    link.disabled = false; paint(true);
    lastState = null;
    say('串口已连接 115200');
    readLoop();
    wline('V');
  }

  async function disconnect() {
    connected = false;
    try { if (rdr) await rdr.cancel(); } catch (e) {}
    try { if (port) await port.close(); } catch (e) {}
    port = null; lastState = null;
    paint(false);
    say('串口已断开');
  }

  link.addEventListener('click', function () { connected ? disconnect() : connect(); });
  paint(false);

  window.__NET = {
    req: async function (p) {
      if (!connected) return undefined;
      var u = new URL(p, 'http://x'), path = u.pathname;
      var g = function (k) { return u.searchParams.get(k); };
      switch (path) {
        case '/api/state':  return lastState || undefined;
        case '/api/params': return await askParams();
        case '/api/stick':  wline('G,' + (g('thr') | 0));
                            wline('Q,' + g('r') + ',' + g('p') + ',' + g('y'));
                            wline('K'); return { ok: 1 };
        case '/api/arm':    wline('A,' + (g('on') === '1' ? 1 : 0)); return { ok: 1 };
        case '/api/stop':   wline('X'); return { ok: 1 };
        case '/api/jog':    wline('J,' + ((+g('i')) + 1) + ',' + g('pm') + ',' + g('ms')); return { ok: 1 };
        case '/api/spin':   wline('S,' + (g('pm') | 0)); return { ok: 1 };
        case '/api/zero':   wline('R'); return { ok: 1 };
        case '/api/level':  wline('L'); return { ok: 1 };
        case '/api/param':  wline('E,' + g('k') + ',' + g('v')); return { ok: 1 };
        case '/api/save':   wline('W'); return { ok: 1 };
        case '/api/load':   wline('U'); return { ok: 1 };
        case '/api/defs':   wline('F'); return { ok: 1 };
      }
      return { ok: 1 };
    }
  };
})();
