"""把 page/mobile.html 同步到两个出口：
1) flight_v1.ino 的 PAGE_HTML（手机 / WiFi 版，去掉串口垫片）
2) web_flight/index.html（USB / Web Serial 版，注入串口垫片）

脚本会自动按当前目录结构找文件，两种布局都支持：
  开发目录：  drone_bringup/{page/, flight_v1/, web_flight/, build_page.py}
  发布包：    ESP32-1S_drone_pack/{02_web/page/, 01_firmware/flight_v1/, 02_web/web_flight/}
"""
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
MARK = "<!--SERIAL_SHIM-->"


def first_existing(paths):
    for p in paths:
        if os.path.isfile(p):
            return p
    return None


def find_up(rel_parts, max_up=4):
    """从脚本所在目录往上找，兼容开发目录和发布包的层级差异"""
    d = HERE
    for _ in range(max_up):
        p = os.path.join(d, *rel_parts)
        if os.path.isfile(p):
            return p
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return None


def main():
    src = first_existing([
        os.path.join(HERE, "mobile.html"),
        os.path.join(HERE, "page", "mobile.html"),
    ])
    if not src:
        print("FAIL: 找不到 mobile.html")
        return 1
    shim_path = first_existing([
        os.path.join(os.path.dirname(src), "serial_shim.js"),
        os.path.join(HERE, "serial_shim.js"),
    ])

    with io.open(src, "r", encoding="utf-8") as f:
        page = f.read()
    if MARK not in page:
        print("FAIL: %s 里没有 %s 标记" % (src, MARK))
        return 1

    # ---------------- 1) 固件版 ----------------
    ino = find_up(("flight_v1", "flight_v1.ino")) or find_up(
        ("01_firmware", "flight_v1", "flight_v1.ino"))
    if ino:
        fw_page = page.replace(MARK + "\n", "")
        if 'R"HTML(' in fw_page or ')HTML"' in fw_page:
            print("FAIL: 页面里含裸 raw-string 分隔符")
            return 1
        fw_page = fw_page.replace("\r\n", "\n")

        with io.open(ino, "r", encoding="utf-8", newline="") as f:
            text = f.read()
        new_text, n = re.subn(
            r'(static const char PAGE_HTML\[\] PROGMEM = R"HTML\()[\s\S]*?(\)HTML";)',
            lambda m: m.group(1) + fw_page + m.group(2),
            text,
            count=1,
        )
        if n != 1:
            print("FAIL: 在 %s 里找不到 PAGE_HTML 块" % ino)
            return 1
        with io.open(ino, "w", encoding="utf-8", newline="") as f:
            f.write(new_text)
        print("  -> %s  (%d 字节页面)" % (ino, len(fw_page)))
    else:
        print("  !! 没找到 flight_v1.ino，跳过固件注入")

    # ---------------- 2) USB 版 ----------------
    if not shim_path:
        print("FAIL: 找不到 serial_shim.js")
        return 1
    with io.open(shim_path, "r", encoding="utf-8") as f:
        shim = f.read()

    usb_target = find_up(("web_flight", "index.html")) or os.path.join(
        os.path.dirname(src), "..", "web_flight", "index.html")
    out = os.path.abspath(usb_target)
    out_dir = os.path.dirname(out)
    if not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    usb_page = page.replace(MARK, "<script>\n" + shim + "\n</script>")
    with io.open(out, "w", encoding="utf-8", newline="\n") as f:
        f.write(usb_page)
    print("  -> %s  (%d 字节)" % (out, len(usb_page)))

    print("OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
