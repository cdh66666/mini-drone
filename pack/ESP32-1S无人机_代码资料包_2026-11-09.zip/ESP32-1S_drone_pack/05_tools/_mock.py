import json, os, sys, time, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "page")

S = {
    "vb": 4120, "arm": 0, "mode": 0, "thr": 0, "sp": 0,
    "d": [0, 0, 0, 0],
    "roll": 1.2, "pitch": -0.8, "yaw": 12,
    "gr": 0.4, "gp": -0.2, "gy": 0.0,
    "ax": 0.01, "ay": -0.02, "az": 0.99,
    "hz": 249, "dt": 4.0, "f": 0, "imu": 1,
}
P = {"angP": 5.0, "rp": 3.2, "ri": 0.05, "rd": 0.06,
     "pp": 3.2, "pi": 0.05, "pd": 0.06, "yp": 2.0,
     "idle": 60, "mthr": 700, "mang": 25, "trMax": 180,
     "trimR": 0.0, "trimP": 0.0, "sgR": 1, "sgP": 1, "sgY": 1}
LOG = []
JOG = [0.0, 0.0, 0.0, 0.0]

lock = threading.Lock()


def now():
    return time.time()


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, f, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        p = u.path
        with lock:
            LOG.append(p + ("?" + u.query if u.query else ""))
            if p in ("/", "/index.html"):
                with open(os.path.join(ROOT, "mobile.html"), "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            if p == "/api/state":
                for i in range(4):
                    S["d"][i] = int(JOG[i]) if JOG[i] > 0 else 0
                return self._send(200, json.dumps(S))
            if p == "/api/params":
                return self._send(200, json.dumps(P))
            if p == "/api/arm":
                on = q.get("on") == "1"
                if on:
                    if S["thr"] != 0:
                        return self._send(200, json.dumps({"ok": 0, "why": "油门不在 0"}))
                    S["arm"] = 1; S["mode"] = 1; S["f"] = 0
                else:
                    S["arm"] = 0; S["mode"] = 0; S["thr"] = 0
                return self._send(200, '{"ok":1}')
            if p == "/api/stick":
                if not S["arm"]:
                    return self._send(200, '{"ok":0}')
                S["thr"] = int(q.get("thr", 0))
                return self._send(200, '{"ok":1}')
            if p == "/api/jog":
                if S["arm"]:
                    return self._send(409, "armed", "text/plain")
                i = int(q.get("i", 0)); pm = int(q.get("pm", 0)); ms = int(q.get("ms", 0))
                end = now() + ms / 1000.0
                if i < 0:
                    for k in range(4):
                        JOG[k] = pm
                elif i < 4:
                    JOG[i] = pm
                threading.Timer(ms / 1000.0, lambda: _clr(i)).start()
                return self._send(200, '{"ok":1}')
            if p == "/api/spin":
                if S["arm"]:
                    return self._send(409, "armed", "text/plain")
                pm = int(q.get("pm", 0))
                S["sp"] = pm; S["mode"] = 2 if pm > 0 else 0
                for k in range(4):
                    S["d"][k] = pm
                    JOG[k] = pm
                return self._send(200, '{"ok":1}')
            if p == "/api/stop":
                S["arm"] = 0; S["mode"] = 0; S["thr"] = 0; S["sp"] = 0
                for k in range(4):
                    S["d"][k] = 0; JOG[k] = 0
                return self._send(200, '{"ok":1}')
            if p in ("/api/zero", "/api/level", "/api/save", "/api/load", "/api/defs"):
                return self._send(200, '{"ok":1}')
            if p == "/api/param":
                k = q.get("k"); v = float(q.get("v", 0))
                if k in ("sgR", "sgP", "sgY"):
                    P[k] = -1 if v < 0 else 1
                elif k in ("idle", "mthr"):
                    P[k] = int(v)
                else:
                    P[k] = v
                return self._send(200, '{"ok":1}')
            if p == "/api/log":
                return self._send(200, json.dumps({"log": LOG[-60:]}, ensure_ascii=False))
            return self._send(404, "nope", "text/plain")


def _clr(i):
    with lock:
        if i < 0:
            for k in range(4):
                JOG[k] = 0
        elif i < 4:
            JOG[i] = 0


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8971
    print("mock on", port, flush=True)
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()
