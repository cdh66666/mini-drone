#!/usr/bin/env python3
"""
本地串口桥：把 ESP32 的串口数据推给浏览器，绕开 Web Serial。

为什么需要这个：
  WorkBuddy 的预览面板跑在 Electron 里，Electron 必须由宿主实现
  `select-serial-port` 回调，否则 navigator.serial.requestPort() 永远
  立刻 reject（报 "No port selected by the user"，列表根本弹不出来）。
  用本脚本自己开串口、再用 SSE 推给页面，任何浏览器都能看。

接口（同源，不需要 CORS）：
  GET  /api/health   -> {"ok":bool,"port":"COM11","err":"..."}
  GET  /api/stream   -> SSE，每行一条固件文本
  POST /api/cmd      -> body 为命令（如 "A"、"P,1,80"），自动补 \\n
  其他路径           -> 当静态文件，根目录 ./web

用法：
  python bridge.py [COM11] [8913]
"""
import json
import os
import queue
import sys
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

try:
    import serial
except ImportError:
    sys.stderr.write("pyserial 缺失：请用 envs\\default 下的 python 运行\n")
    raise

HERE = os.path.dirname(os.path.abspath(__file__))
WEB_ROOT = os.path.join(HERE, "web")

SER_PORT = sys.argv[1] if len(sys.argv) > 1 else "COM11"
HTTP_PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 8913
BAUD = 115200

_clients = []
_clients_lock = threading.Lock()
_ser = None
_ser_lock = threading.Lock()
_status = {"open": False, "err": "not opened", "port": SER_PORT}


def open_serial():
    global _ser
    try:
        s = serial.Serial(SER_PORT, BAUD, timeout=0.15)
        # 不要碰 DTR/RTS：原生 USB CDC 下这两根线会干扰板子
        s.dtr = False
        s.rts = False
        _ser = s
        _status["open"] = True
        _status["err"] = ""
    except Exception as e:
        _status["open"] = False
        _status["err"] = str(e)


def reader_loop():
    global _ser
    buf = b""
    while True:
        if _ser is None:
            time.sleep(0.3)
            open_serial()
            continue
        try:
            chunk = _ser.read(8192)
        except Exception as e:
            _status["open"] = False
            _status["err"] = str(e)
            try:
                _ser.close()
            except Exception:
                pass
            _ser = None
            time.sleep(0.6)
            continue
        if not chunk:
            continue
        buf += chunk
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            text = line.decode("utf-8", "replace").rstrip("\r")
            if not text:
                continue
            with _clients_lock:
                for q in _clients:
                    try:
                        q.put_nowait(text)
                    except queue.Full:
                        pass


class Handler(SimpleHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=WEB_ROOT, **kw)

    def log_message(self, fmt, *args):
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _chunk(self, data: bytes):
        self.wfile.write(("%X\r\n" % len(data)).encode() + data + b"\r\n")
        self.wfile.flush()

    def do_GET(self):
        if self.path.startswith("/api/health"):
            self._json(_status)
            return
        if self.path.startswith("/api/stream"):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-store")
            self.send_header("X-Accel-Buffering", "no")
            self.send_header("Transfer-Encoding", "chunked")
            self.end_headers()
            q = queue.Queue(maxsize=4000)
            with _clients_lock:
                _clients.append(q)
            try:
                self._chunk(b": connected\n\n")
                while True:
                    try:
                        line = q.get(timeout=15)
                    except queue.Empty:
                        self._chunk(b": ping\n\n")
                        continue
                    self._chunk(("data: " + line + "\n\n").encode("utf-8"))
            except Exception:
                pass
            finally:
                with _clients_lock:
                    if q in _clients:
                        _clients.remove(q)
            return
        if self.path == "/":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        if not self.path.startswith("/api/cmd"):
            self._json({"ok": False, "err": "not found"}, 404)
            return
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n).decode("utf-8", "replace").strip()
        ok = False
        err = ""
        if not raw:
            err = "empty"
        elif _ser is None:
            err = "serial not open"
        else:
            try:
                with _ser_lock:
                    _ser.write((raw + "\n").encode())
                ok = True
            except Exception as e:
                err = str(e)
        self._json({"ok": ok, "err": err})


def main():
    open_serial()
    threading.Thread(target=reader_loop, daemon=True).start()
    srv = ThreadingHTTPServer(("127.0.0.1", HTTP_PORT), Handler)
    srv.daemon_threads = True
    print("BRIDGE READY  http://127.0.0.1:%d/  serial=%s open=%s %s"
          % (HTTP_PORT, SER_PORT, _status["open"], _status["err"]), flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
