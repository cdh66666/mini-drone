const { chromium } = require('playwright-core');
const fs = require('fs');
const path = require('path');

function findChrome() {
  const base = path.join(process.env.LOCALAPPDATA, 'ms-playwright');
  const dirs = fs.readdirSync(base).filter(d => d.startsWith('chromium-'));
  for (const d of dirs) {
    const p = path.join(base, d, 'chrome-win64', 'chrome.exe');
    if (fs.existsSync(p)) return p;
  }
  throw new Error('no chromium');
}

(async () => {
  const log = [];
  const browse = await chromium.launch({ executablePath: findChrome(), args: ['--no-sandbox'] });
  const ctx = await browse.newContext({
    viewport: { width: 390, height: 844 }, deviceScaleFactor: 2,
    isMobile: true, hasTouch: true, userAgent:
      'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
  });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errs.push('CONSOLE ' + m.text()); });

  await page.goto('http://127.0.0.1:8971/', { waitUntil: 'load' });
  await page.waitForTimeout(900);

  const shot = async n => { await page.screenshot({ path: `shot_${n}.png` }); };
  const state = async () => {
    const r = await page.evaluate(() => fetch('/api/state').then(x => x.json()));
    return r;
  };

  // ---- 首屏 ----
  log.push('volt=' + await page.textContent('#vb'));
  log.push('pill=' + await page.textContent('#md'));
  log.push('offlineHidden=' + await page.evaluate(() => document.getElementById('offline').hidden));
  await shot('1_att');

  // ---- 电机 ----
  await page.click('.tab[data-tab="mot"]');
  await page.waitForTimeout(200);
  await page.click('.mcard[data-i="0"]');
  await page.waitForTimeout(700);
  log.push('after jog d0=' + JSON.stringify((await state()).d));
  await shot('2_mot');

  // 起转滑杆
  await page.evaluate(() => {
    const el = document.getElementById('spin');
    el.value = 120;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await page.waitForTimeout(700);
  log.push('spin sv=' + await page.textContent('#sv') + ' mode=' + (await state()).mode);

  // ---- 飞行：长按解锁 ----
  await page.click('.tab[data-tab="fly"]');
  await page.waitForTimeout(200);
  const arm = await page.$('#arm');
  const bb = await arm.boundingBox();
  await page.mouse.move(bb.x + bb.width / 2, bb.y + bb.height / 2);
  await page.mouse.down();
  await page.waitForTimeout(300);
  await shot('3_arm_hold');
  log.push('holding label=' + await page.textContent('#armlab'));
  await page.waitForTimeout(700);
  await page.mouse.up();
  await page.waitForTimeout(600);
  log.push('armed=' + (await state()).arm + ' lab=' + await page.textContent('#armlab'));
  await shot('4_armed');

  // 油门
  await page.click('#tp'); await page.click('#tp'); await page.click('#tp');
  await page.waitForTimeout(500);
  log.push('thr=' + (await state()).thr + ' tv=' + await page.textContent('#tv'));

  // 杆位按住 + 拖出按钮（不该卡住）
  const up = await (await page.$('#up')).boundingBox();
  await page.mouse.move(up.x + up.width / 2, up.y + up.height / 2);
  await page.mouse.down();
  await page.waitForTimeout(250);
  log.push('sticktag(按住)=' + await page.textContent('#stickt'));
  await page.mouse.move(up.x + up.width / 2, up.y - 60); // 拖出
  await page.waitForTimeout(250);
  log.push('sticktag(拖出后)=' + await page.textContent('#stickt'));
  await page.mouse.up();
  await shot('5_fly');

  // ---- 参数 ----
  await page.click('.tab[data-tab="par"]');
  await page.waitForTimeout(400);
  await shot('6_param');
  const angProw = await page.$('.pr');
  await angProw.asElement().$eval('.stp:last-child', b => b.click());
  await page.waitForTimeout(600);
  log.push('angP=' + JSON.stringify(await page.evaluate(() => fetch('/api/params').then(x => x.json()).then(j => j.angP))));

  // 方向翻转两次
  const sg = await page.$('.sg[data-k="sgR"]');
  await sg.click(); await page.waitForTimeout(450);
  log.push('sgR1=' + await page.textContent('.sg[data-k="sgR"] b') + '/' + (await page.evaluate(() => fetch('/api/params').then(x => x.json()).then(j => j.sgR))));
  await sg.click(); await page.waitForTimeout(450);
  log.push('sgR2=' + await page.textContent('.sg[data-k="sgR"] b') + '/' + (await page.evaluate(() => fetch('/api/params').then(x => x.json()).then(j => j.sgR))));

  // 保存（两段式）
  await page.click('#save'); await page.waitForTimeout(150);
  log.push('save1=' + await page.textContent('#save'));
  await page.click('#save'); await page.waitForTimeout(400);
  log.push('save2=' + await page.textContent('#save'));

  // ---- 停止 ----
  await page.click('#stop');
  await page.waitForTimeout(600);
  log.push('after stop arm=' + (await state()).arm + ' thr=' + (await state()).thr);

  // ---- 断开重连提示 ----
  await page.route('**/api/**', r => r.abort());
  await page.waitForTimeout(1400);
  log.push('offlineShown=' + await page.evaluate(() => !document.getElementById('offline').hidden) +
    ' text=' + await page.textContent('#offline'));
  await shot('7_offline');

  console.log(log.join('\n'));
  console.log('--- errors ---');
  console.log(errs.length ? errs.join('\n') : 'none');
  await browse.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
