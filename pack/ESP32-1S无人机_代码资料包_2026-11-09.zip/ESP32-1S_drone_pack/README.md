# ESP32-1S-Basic-R4-E07 迷你四轴 · 代码与资料包

打包日期：2026-11-09　　固件版本：`flight-v1`　　页面版本：手机调试台 v2

---

## 一、这是什么

一块自己画板打样的 **ESP32-S3 1S 四轴**（板号 ESP32-1S-Basic-R4-E07）从"空板点亮"到"能飞"的全过程产物：

- 硬件实测记录（电源 / 充电 / 四路栅极 / IMU / 射频 / USB 全部实测过）
- 5 个固件版本，从自检 → 台架调试 → 振动测量 → 手机热点调试 → 完整飞控
- 手机调试台（网页，连热点即用，带 OTA 刷机）
- 电脑端 USB 直连调试页
- 编译好的 .bin（可直接刷，也可 OTA）
- **电路资料**：原理图 PDF、PCB 图 PDF、KiCad 工程 + Gerber + BOM（见 `06_hardware/`）

**当前状态**：飞控固件已编译通过并做过地面验证（四路驱动、桨向、IMU、OTA 全部 OK），
**尚未首飞**——参数留给你自己按下面第 6 节的顺序调。

---

## 二、目录

```
ESP32-1S_drone_pack/
├─ README.md                     ← 本文件
├─ 01_firmware/                  ← 全部源码（Arduino IDE / arduino-cli 直接打开）
│   ├─ flight_v1/                ★ 主飞控（串级 PID + 自稳 + 手机热点 + OTA）
│   ├─ drone_bench_v5/           台架 v5：IMU 振动测量 + Butterworth 滤波
│   ├─ drone_bench_v4/           台架 v4：去掉解锁的裸输出（测升力用）
│   ├─ drone_bench_v3/           台架 v3：单通道限制 + 看门狗
│   ├─ drone_ap_v1/              手机热点调试台（无 PID，纯手动占空比）
│   └─ 00_自检固件_bringup_v2.ino  空板上电自检（不改硬件就能验证板子好坏）
├─ 02_web/
│   ├─ page/mobile.html          ★ 手机调试台唯一源文件
│   ├─ page/serial_shim.js       USB 版串口适配层（注入用）
│   ├─ build_page.py             一键同步：页面 → 固件内嵌页 + USB 版
│   ├─ web_flight/index.html     USB 直连版（Chrome/Edge 打开，Web Serial）
│   └─ web/index.html            最早的调试台（老协议，留档）
├─ 03_bin/
│   ├─ flight_v1.ino.bin         ★ OTA 用（手机上传这个）
│   ├─ flight_v1.ino.merged.bin  整片烧录用（含 bootloader + 分区表，0x0 起）
│   ├─ flight_v1.ino.bootloader.bin / .partitions.bin / boot_app0.bin
│   ├─ flash_args.txt            esptool 地址表
│   └─ 烧录说明.txt
├─ 04_docs/
│   ├─ 测试报告_2026-11-08.md     ★ 全部实测数据（电源/栅极/IMU/射频）
│   ├─ serial_自检输出_v1.log / v2.log
│   ├─ 遥测_接电池后.log
│   └─ screenshots/              手机调试台各页截图
├─ 05_tools/
│   ├─ bridge.py                 电脑端串口桥（SSE 推给浏览器，绕开 Web Serial）
│   ├─ _mock.py                  模拟飞控 HTTP 接口（改页面时先在这里试）
│   └─ _uitest.js                Playwright 手机视口自动化测试脚本
└─ 06_hardware/                  ★ 电路资料
    ├─ 00_硬件资料说明.md         引脚对照表 + 器件表 + 版本警告（先看这个）
    ├─ 01_原理图_SCH_ESP32-1S-Basic-R4-E07_2026-11-08.pdf
    ├─ 02_PCB图_PCB_ESP32-1S-Basic-R4-E07_2026-11-08.pdf
    └─ 03_KiCad工程与制造文件_20261109.zip   KiCad 工程 + Gerber + BOM（177 文件）
```

---

## 三、硬件事实（实测，不是抄资料）

### 3.1 主控与存储

| 项 | 实测值 |
| --- | --- |
| 芯片 | ESP32-S3 rev v0.2，双核 240 MHz |
| MAC | `7C:0C:5F:8E:B7:DC` |
| Flash | 8 MB（GigaDevice，quad，80 MHz）→ 模块 **N8** |
| PSRAM | 2 MB，读写正常 → 模块 **R2** |
| 出厂状态 | 全 0xFF 空片（不存在覆盖别人固件的问题） |
| 开发框架 | arduino-esp32 3.3.11 / ESP-IDF v5.5.5 |

### 3.2 引脚

| 功能 | GPIO | 备注 |
| --- | --- | --- |
| 电机 M1（前左） | 4 | → 330R → Q1 栅极，100k 下拉 |
| 电机 M2（前右） | 5 | → 330R → Q2 |
| 电机 M3（后左） | 6 | → 330R → Q3 |
| 电机 M4（后右） | 7 | → 330R → Q4 |
| I2C SDA | 10 | QMI8658A @ `0x6B` |
| I2C SCL | 11 | |
| VBAT_ADC | 2 | 100k/100k 分压，`VBAT_DIV = 2.0` |
| USB_PGOOD_N | 9 | 低电平 = USB 已插入 |

板子方位：**USB 口一侧是机尾**，M1/M2 在机头。

> 原理图网标（`PWM1..4` / `IMU_SDA` / `VBAT_ADC` / `USB_PGOOD_N`）、U1 焊盘编号、
> 测试点 TP1–TP6 的完整对照表在 **`06_hardware/00_硬件资料说明.md` 第二节**，
> 已和上面的引脚定义逐条核对一致。

### 3.3 电源与充电

- U4 = **BQ24073** 线性充电管理，USB 插入时给电池充电并给系统供电。
- 实测：插 USB 时充电电流约 **189 mA**，电池端 4.16 V。
- 裸板无电池时会周期性做电池检测，BAT 脚在 3.76 ↔ 4.15 V 之间跳——**不是故障**，
  但此时电机焊盘带电，别拿镊子碰。

### 3.4 电机驱动拓扑（很重要）

```
VBAT ── 电机 ── JMx ── Qx(NMOS, CJ3400) ── GND
```

**低边斩波、只能单向导通**。也就是说：

- 固件**无法反转电机转向**，想换向只能**物理对调电机的两根线**；
- PWM 占空比 = 转速，没有 H 桥，没有刹车；
- 这是本板设计决定，不是 bug。四轴刚好只需要一个方向，靠正反桨配对解决反扭。

（栅极串 330R、下拉 100k，电机两端各并一颗 SS34 续流二极管，见 `06_hardware/`。）

现在的接法（已确认）：四路风都朝下吹，对角同向、相邻反向（M1 M4 一组，M2 M3 一组）。

### 3.5 实测基线

| 项 | 数值 |
| --- | --- |
| 整机重量（含桨、不含线） | 37.8 g |
| 插 USB 线时 | 45.9 g |
| 电池电压 | 4.16 V（满电 1S） |
| 单电机约 50% 占空比 | 接近离地（悬停点大概就在这附近） |

---

## 四、编译

### 4.1 环境

- arduino-cli ≥ 1.5（或 Arduino IDE 2.x）
- esp32 core 3.3.x（`arduino-cli core install esp32:esp32`）

### 4.2 命令

```bash
arduino-cli compile \
  --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=8M,PSRAM=enabled,PartitionScheme=min_spiffs,USBMode=hwcdc" \
  flight_v1
```

**FQBN 四个选项不能省**：

| 选项 | 为什么必须 |
| --- | --- |
| `CDCOnBoot=cdc` | 板上是原生 USB，不打开就看不到串口 |
| `FlashSize=8M` | 实际是 N8 模块 |
| `PSRAM=enabled` | 实际是 R2 |
| `PartitionScheme=min_spiffs` | 必须有 **otadata + 双 app 分区**，否则 OTA 刷不了 |

当前占用：Flash 53%（1 043 254 B / 1 966 080 B），RAM 14%。

### 4.3 页面和固件的关系（改页面必看）

手机调试页是**内嵌在固件里的字符串**（`PAGE_HTML`）。为了不维护两份，源文件统一放在
`02_web/page/mobile.html`，用脚本同步：

```bash
python build_page.py
```

它做两件事：
1. 把 `mobile.html` 注入 `01_firmware/flight_v1/flight_v1.ino` 的 `PAGE_HTML`
2. 把 `mobile.html` + `serial_shim.js` 合成 `02_web/web_flight/index.html`（USB 版）

**不要直接改 .ino 里的 HTML**，下次一跑脚本就被覆盖。

---

## 五、烧录

### 方式 A：USB 整片烧（空板 / 救砖 / 换分区表时用这个）

板子插 USB-C，进下载模式（一般直接插上就行，ESP32-S3 原生 USB 支持自动复位）：

```bash
esptool.py --chip esp32s3 -p COM11 -b 460800 \
  --before default_reset --after hard_reset write_flash \
  --flash_mode dio --flash_freq 80m --flash_size 8MB \
  0x0      flight_v1.ino.bootloader.bin \
  0x8000   flight_v1.ino.partitions.bin \
  0xe000   boot_app0.bin \
  0x10000  flight_v1.ino.bin
```

或者一条命令烧合并镜像（最简单）：

```bash
esptool.py --chip esp32s3 -p COM11 -b 460800 write_flash 0x0 flight_v1.ino.merged.bin
```

### 方式 B：arduino-cli 直接上传

```bash
arduino-cli upload -p COM11 --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=8M,PSRAM=enabled,PartitionScheme=min_spiffs,USBMode=hwcdc" flight_v1
```

### 方式 C：手机 OTA（日常更新用这个）

1. 板子上电，手机 Wi-Fi 连 **DroneBench**（开放网络，无密码）
2. 打开 `http://192.168.4.1/` → 底部「参数」→「上传 .bin 刷固件」
3. 选 `03_bin/flight_v1.ino.bin`，等 10–20 秒
4. 自动重启，热点断一下，重连即可

> **首次必须是方式 A 或 B**（空片里没有网页，没得 OTA）。之后所有更新都能走手机。
> 判断 OTA 是否可用：串口发 `O`，回 `can=1` 就行。

---

## 六、调试顺序（从台面到离地）

手机连热点打开页面后，底栏 4 个标签：**状态 / 电机 / 飞行 / 参数**。

| 步骤 | 在哪做 | 做什么 | 判据 |
| --- | --- | --- | --- |
| ① 电机检查 | 电机页 | 逐个点 M1–M4 | 每个桨的风都**朝下吹**；对角同向、相邻反向；四路同开 1.5 秒机身**不自转** |
| ② 姿态方向 | 状态页 | 端起机身 | 右滚 roll 变大、抬头 pitch 变大、机头右转 yaw 变大；反了去「参数 → 方向修正」 |
| ③ 水平归零 | 参数页 | 把机放平后点「水平归零」 | 归零后姿态显示 ≈ 0° |
| ④ 起转点 | 电机页 | 慢慢拉起转滑杆 | 找到四路都能稳定转起来的最低档，点「记为怠速」（留 0 也能飞） |
| ⑤ 解锁试转 | 飞行页 | 长按 0.8 秒解锁 → 油门 12% | 四路一起加速、机身不偏、不抖 |
| ⑥ 找悬停点 | 飞行页 | 每次 +3% | 离地那一刻就是悬停油门，记下来 |

**注意**：
- 想换向只能换电机线（见 3.4），固件里没有转向设置。
- 用电子秤测推力**不准**：风压和推力在"桨 + 秤盘"这个系统里是内力，互相抵消，
  读数只涨一两克噪声。正确做法是找"刚好离地"的油门。
- 调试时页面切后台 / 关掉，0.9 秒后固件自动上锁；倾角超 55° 持续 0.4 秒也会自动停。

---

## 七、串口命令（115200，USB 直连）

| 命令 | 作用 |
| --- | --- |
| `V` | 打印版本 / MAC / IMU 地址 / 热点信息 |
| `A,1` / `A,0` | 解锁 / 上锁 |
| `G,<0..1000>` | 油门指令（‰） |
| `Q,<r>,<p>,<y>` | 杆位注入（-1..1） |
| `S,<0..250>` | 起转测试（四路等值直出，不经混控） |
| `J,<1..4>,<pm>,<ms>` | 单路点动，到点自停；`J,0,...` = 四路同开 |
| `X` | 全部停止 + 上锁 |
| `R` | 陀螺零偏标定（机身必须静止） |
| `L` | 水平归零 |
| `E,<k>,<v>` | 在线改参数，如 `E,rp,3.5` |
| `C` | 打印全部参数（`#PARAMS,{json}`） |
| `W` / `U` / `F` | 保存 / 重载 / 恢复默认 |
| `O` | OTA 能力自检（运行分区 / 可写分区 / 容量） |
| `Z` | 自检（混控符号 / 限幅 / PID 方向），打印 PASS/FAIL |
| `K` | 心跳（喂看门狗） |
| `P` | 环内状态回读（`#DBG`） |

固件还会周期性输出 `#S,{json}`（200 ms 一帧状态），USB 版页面就靠它刷界面。

---

## 八、HTTP 接口（热点 `192.168.4.1`）

| 路径 | 说明 |
| --- | --- |
| `GET /` | 手机调试页 |
| `GET /update` | OTA 上传页 |
| `POST /api/update` | 固件上传（multipart 字段名 `firmware`） |
| `GET /api/state` | 状态 JSON：电压/模式/油门/四路输出/姿态/陀螺/加计/环频/故障位 |
| `GET /api/params` | 全部参数 |
| `GET /api/arm?on=0\|1` | 上锁 / 解锁（失败返回 `{"ok":0,"why":"..."}`） |
| `GET /api/stick?thr=&r=&p=&y=` | 杆位 + 油门 |
| `GET /api/jog?i=&pm=&ms=` | 点动（`i=0..3`，`i=-1` 四路） |
| `GET /api/spin?pm=` | 起转测试 |
| `GET /api/stop` | 停止 + 上锁 |
| `GET /api/zero` / `level` | 零偏 / 水平归零 |
| `GET /api/param?k=&v=` | 改单个参数 |
| `GET /api/save` / `load` / `defs` | 存盘 / 重载 / 默认 |

故障位：`1` IMU 异常、`2` 链路超时、`4` 倾角保护、`8` 低电压。

---

## 九、参数

| 参数 | 默认 | 范围 | 含义 |
| --- | --- | --- | --- |
| `angP` | 6.0 | 0–20 | 角度外环 P（把倾角误差换成角速度目标） |
| `rp` / `ri` / `rd` | 3.0 / 0.15 / 0.06 | — | Roll 角速度环 PID |
| `pp` / `pi` / `pd` | 3.0 / 0.15 / 0.06 | — | Pitch 角速度环 PID |
| `yp` | 0.0 | 0–8 | Yaw 角速度 P（0 = 不做 yaw 控制） |
| `idle` | 0 | 0–300 ‰ | 怠速：解锁后电机不停转的底值 |
| `mthr` | 700 | 100–1000 ‰ | 最大油门上限 |
| `mang` | 25 | 5–45 ° | 自稳最大倾角 |
| `trMax` | 250 | 30–500 dps | 角速度目标上限 |
| `sgR/sgP/sgY` | 1 / 1 / −1 | ±1 | IMU 轴符号 |
| `trimR/trimP` | 0 | — | 水平归零补偿 |

**调参建议**：先只用 `rp/pp` 的 P 把姿态"硬"起来，抖动就降 `rd/pd`；
`ri/pi` 从 0.05 慢慢加，加多了会低频摆动。

---

## 十、安全机制（固件里已生效）

| 机制 | 阈值 |
| --- | --- |
| 解锁前检查 | 油门 = 0、倾角 < 20°、角速度 < 25 dps、电压 > 3.3 V、IMU 就绪 |
| 链路超时 | 解锁后 900 ms 收不到指令 → 立即上锁；起转测试 1000 ms |
| 倾角保护 | 倾角 > 55° 持续 0.4 s → 上锁 |
| 低电保护 | 电压 < 3.25 V → 上锁 |
| 软启动 | 解锁后 0.5 s 内输出渐入，避免四路瞬间冲击 |
| 控制权限渐入 | 油门行程 6% 开始给姿态环权限，25% 给满（台面上不抖） |
| Web 硬限幅 | 单路 ≤ 700‰，四路同开 ≤ 500‰，起转 ≤ 250‰ |

---

## 十一、已知限制 / 坑（都踩过）

1. **电机只能单向**：换向必须换线，固件没有 reverse 参数。
2. **秤测推力无效**：风压是系统内力，读数不涨。找离地油门。
3. **atime 不可信**（本机 NTFS）：判断文件新旧只能看修改时间。
4. **WorkBuddy 预览面板的 Web Serial 用不了**：Electron 没实现 `select-serial-port`。
   USB 版请用 **Chrome / Edge** 打开 `web_flight/index.html`。
5. **iOS 缓存**：`/api/*` 已加 `no-store`，否则 Safari 会拿旧状态。
6. **yaw 纯陀螺积分会漂**：没有磁力计，属正常现象，不用管。
7. **页面别在电脑上直接双击打开**：HTTP 版必须由板子提供（`file://` 下 fetch 会失败）。

---

## 十二、版本演进

| 版本 | 目的 | 关键内容 |
| --- | --- | --- |
| `bringup_v2` | 空板自检 | 强制 PWM 拉低，逐脚测栅极网络，无电机动作 |
| `drone_bench_v3` | 接电池后 | 启动即上锁、单通道限制、300‰ 硬限幅、700 ms 看门狗 |
| `drone_bench_v4` | 测四点升力 | 去掉解锁握手、放开四路同时输出 |
| `drone_bench_v5` | IMU 振动 | 连续高速采样 + 二阶 Butterworth，输出 RMS/重复率 |
| `drone_ap_v1` | 手机调试 | 自带热点 + captive portal 自动弹页 |
| **`flight_v1`** | **能飞** | 串级 PID、X 型混控带饱和缩放、互补滤波、全部安全机制、手机页、OTA |

---

## 十三、快速排错

| 现象 | 原因 / 处理 |
| --- | --- |
| 串口列表里没有板子 | 检查 USB 线是否只供电；FQBN 是否带 `CDCOnBoot=cdc`；换数据线 |
| 手机连上热点不弹页 | 手动打开 `http://192.168.4.1/` |
| 页面一直"连接中" | 板子没上电 / 没连热点 / 固件不是 flight_v1 |
| 解锁被拒 | 看 toast 原因：油门不为 0、机身没放平、还在动、电压低、起转测试没停 |
| OTA 上传失败 | 确认传的是 `flight_v1.ino.bin`（不是 merged），确认分区是 min_spiffs（`O` 命令查 `can=1`） |
| 电机不转 | 先看「状态 → 电机输出」有没有数值；有数值不转 = 接线/焊点问题 |

---

_包里所有数据来自 2026-11-08/09 的实测，详细过程见 `04_docs/测试报告_2026-11-08.md`。_
